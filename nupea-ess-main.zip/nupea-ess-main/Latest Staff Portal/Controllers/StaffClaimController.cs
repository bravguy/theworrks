﻿using Latest_Staff_Portal.CustomSecurity;
using Latest_Staff_Portal.Models;
using Latest_Staff_Portal.Utils;
using Latest_Staff_Portal.ViewModel;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.Mvc;

namespace Latest_Staff_Portal.Controllers
{
    [CustomeAuthentication]
    [CustomAuthorization(Role = "ALLUSERS")]
    public class StaffClaimController : Controller
    {
        public ActionResult StaffClaims(string status)
        {
            try
            {
                if (Session["Username"] == null)
                {
                    return RedirectToAction("Login", "Login");
                }
                ViewBag.Status = status;
                return View();
            }
            catch (Exception ex)
            {
                Error erroMsg = new Error();
                erroMsg.Message = ex.Message.Replace("'", "");
                return View("~/Views/Common/ErrorMessange.cshtml", erroMsg);
            }
        }
        public PartialViewResult StaffClaimsList(string status)
        {
            try
            {
                string staffNo = Session["Username"].ToString();
                List<StaffClaims> staffClaims = new List<StaffClaims>();
                var employee = Session["EmployeeData"] as EmployeeView;
                var station = employee?.GlobalDimension1Code;
                var page = "";
                if (string.IsNullOrEmpty(status))
                {
                    page = "StaffClaims?$filter=Account_No eq '" + staffNo + "' and Document_Type eq 'Staff Claims'&format=json";
                }
                else
                {
                    page = "StaffClaims?$filter=Shortcut_Dimension_1_Code eq '" + station + "' and Document_Type eq 'Staff Claims' and Status eq '"+status+"'&$format=json";

                }
                HttpWebResponse httpResponse = Credentials.GetOdataData(page);
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();

                    var details = JObject.Parse(result);
                    foreach (var jToken in details["value"])
                    {
                        var config = (JObject)jToken;
    
                        var claim = new StaffClaims
                        {
                            No = (string)config["No"],
                            Date = (string)config["Date"],
                            AccountType = (string)config["Account_Type"],
                            AccountNo = (string)config["Account_No"],
                            AccountName = (string)config["Account_Name"],
                            PayingBankAccount = (string)config["Paying_Bank_Account"],
                            BankName = (string)config["Bank_Name"],
                            Payee = (string)config["Payee"],
                            PaymentNarration = (string)config["Payment_Narration"],
                            ShortcutDimension1Code = (string)config["Shortcut_Dimension_1_Code"],
                            DepartmentName = (string)config["Department_Name"],
                            ShortcutDimension2Code = (string)config["Shortcut_Dimension_2_Code"],
                            ProjectName = (string)config["Project_Name"],
                            TotalAmountLCY = (decimal)config["Total_Amount_LCY"],
                            StrategicPlan = (string)config["Strategic_Plan"],
                            ReportingYearCode = (string)config["Reporting_Year_Code"],
                            WorkplanCode = (string)config["Workplan_Code"],
                            ActivityCode = (string)config["Activity_Code"],
                            ExpenditureRequisitionCode = (string)config["Expenditure_Requisition_Code"],
                            Status = (string)config["Status"],
                            DimensionSetId = (string)config["Dimension_Set_ID"],
                            Posted = (string)config["Posted"],
                        };
                        staffClaims.Add(claim);
                    }

                }
                return PartialView("~/Views/StaffClaim/PartialViews/StaffClaimsList.cshtml", staffClaims.OrderByDescending(x => x.No));
            }
            catch (Exception ex)
            {
                Error erroMsg = new Error();
                erroMsg.Message = ex.Message.Replace("'", "");
                return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
            }
        }
        [HttpPost]
        public ActionResult StaffClaimDocumentView(string DocNo)
        {
            try
            {
                if (Session["Username"] == null)
                {
                    return RedirectToAction("Login", "Login");
                }

                StaffClaims claim = new StaffClaims();
                string page = "StaffClaims?$filter=No eq '" + DocNo + "'&format=json";
                HttpWebResponse httpResponse = Credentials.GetOdataData(page);
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();

                    var details = JObject.Parse(result);
                    foreach (var jToken in details["value"])
                    {
                        var config = (JObject)jToken;
    
                        claim = new StaffClaims
                        {
                            No = (string)config["No"],
                            Date = (string)config["Date"],
                            AccountType = (string)config["Account_Type"],
                            AccountNo = (string)config["Account_No"],
                            AccountName = (string)config["Account_Name"],
                            PayingBankAccount = (string)config["Paying_Bank_Account"],
                            BankName = (string)config["Bank_Name"],
                            Payee = (string)config["Payee"],
                            PaymentNarration = (string)config["Payment_Narration"],
                            ShortcutDimension1Code = (string)config["Shortcut_Dimension_1_Code"],
                            DepartmentName = (string)config["Department_Name"],
                            ShortcutDimension2Code = (string)config["Shortcut_Dimension_2_Code"],
                            ProjectName = (string)config["Project_Name"],
                            TotalAmountLCY = (decimal)config["Total_Amount_LCY"],
                            StrategicPlan = (string)config["Strategic_Plan"],
                            ReportingYearCode = (string)config["Reporting_Year_Code"],
                            WorkplanCode = (string)config["Workplan_Code"],
                            ActivityCode = (string)config["Activity_Code"],
                            ExpenditureRequisitionCode = (string)config["Expenditure_Requisition_Code"],
                            Status = (string)config["Status"],
                            DimensionSetId = (string)config["Dimension_Set_ID"],
                            Posted = (string)config["Posted"],
                            AvailableAmount = ((decimal)config["Available_Amount"]).ToString("C", new CultureInfo("sw-KE")),
                            CommittedAmount = ((decimal)config["Committed_Amount"]).ToString("C", new CultureInfo("sw-KE")),
                            AieReceipt = (string)config["AIE_Receipt"],
                        };
                    }

                }
                return View(claim);
            }
            catch (Exception ex)
            {
                Error erroMsg = new Error();
                erroMsg.Message = ex.Message.Replace("'", "");
                return View("~/Views/Common/ErrorMessange.cshtml", erroMsg);
            }
        }
        public PartialViewResult StaffClaimLines(string DocNo, string Status)
        {
            try
            {
                ViewBag.Status = Status;
                List<StaffClaimLines> claimLines = new List<StaffClaimLines>();
                string pageLine = "StaffClaimLines?$filter=No eq '" + DocNo + "'&format=json";
                HttpWebResponse httpResponseLine = Credentials.GetOdataData(pageLine);
                using (var streamReader = new StreamReader(httpResponseLine.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();

                    var details = JObject.Parse(result);
                    foreach (var jToken in details["value"])
                    {
                        var config = (JObject)jToken;

                        StaffClaimLines claim = new StaffClaimLines
                        {
                            No = (string)config["No"],
                            LineNo = (int)config["Line_No"],
                            Type = (string)config["Type"],
                            AccountType = (string)config["Account_Type"],
                            AccountNo = (string)config["Account_No"],
                            AccountName = (string)config["Account_Name"],
                            Description = (string)config["Description"],
                            Amount = (int)config["Amount"],
                            AmountLCY = (int)config["Amount_LCY"],
                            ValidatedBankName = (string)config["Payee_Bank_Acc_Name"],
                        };

                        claimLines.Add(claim);
                    }
                }
                return PartialView("~/Views/StaffClaim/PartialViews/StaffClaimLines.cshtml", claimLines);
            }
            catch (Exception ex)
            {
                Error erroMsg = new Error();
                erroMsg.Message = ex.Message.Replace("'", "");
                return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
            }
        }
        public JsonResult DeleteStaffClaimExpense(string DocNo, int lineNo)
        {
            try
            {
                EmployeeView employee = Session["EmployeeData"] as EmployeeView;
                string empNo = employee?.No;
                var userId = employee?.UserID;
                Credentials.ObjNav.deleteStaffClaimLine(empNo, DocNo, lineNo);
                LogHelper.Log(DocNo, userId, "Delete staff claim lines");

                return Json(new { message = "Staff claim Line Deleted Successfully", success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false }, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult GenerateFo22Report(string docNo)
        {
            try
            {
                var staffNo = Session["Username"].ToString();
                var _filename = staffNo.Replace("/", "");
                var message = "";
                bool success = false, view = false;

                var employeeView = Session["EmployeeData"] as EmployeeView;
                var dimension = employeeView?.GlobalDimension1Code;

                message = Credentials.ObjNav.GenerateClaimsReport(docNo);
                if (string.IsNullOrEmpty(message))
                {
                    success = false;
                    message = "File Not Found";
                }
                else
                {
                    success = true;
                }

                return Json(new { message, success, view }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message, success = false }, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult CreateStaffClaimHeader()
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;
                var staffNo = Session["Username"].ToString();
                var UserID = employee.UserID;

                if (string.IsNullOrEmpty(staffNo))
                {
                    return Json(new { message = "User session expired. Please login again.", success = false },
                        JsonRequestBehavior.AllowGet);
                }

                var docNo = Credentials.ObjNav.FnCreateStaffClaim(UserID);

                RedirectToAction("StaffClaimDocumentView", new { DocNo = docNo });
                return Json(new { message = docNo, success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult NewStaffClaimLine(string docNo)
        {
            try
            {
                if (Session["Username"] == null)
                {
                    return RedirectToAction("Login", "Login");
                }

                var employee = Session["EmployeeData"] as EmployeeView;
                var claimLine = new ClaimLineViewModel();
                Session["httpResponse"] = null;


                // Get gl account List
                var glAccountList = new List<DropdownList>();
                var pageGlAccounts = "GLAccounts?$filter=Available_for_workplaning eq true&$format=json";
                var httpResponseAccounts = Credentials.GetOdataData(pageGlAccounts);
                using (var streamReader = new StreamReader(httpResponseAccounts.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var details = JObject.Parse(result);
                    glAccountList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["No"]} - {(string)config["Name"]}", Value = (string)config["No"] });
                }

                // Get staff claim types
                var claimTypesList = new List<DropdownList>();
                var pageClaimTypes = "StaffClaimTypes";
                var httpResponseClaimTypes = Credentials.GetOdataData(pageClaimTypes);
                using (var streamReader = new StreamReader(httpResponseClaimTypes.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var details = JObject.Parse(result);
                    claimTypesList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["Code"]} - {(string)config["Description"]}", Value = (string)config["Code"] });
                }

                // Get funding source List
                var fundingSourceList = new List<DropdownList>();
                var pageFundingSource = "DimensionValueList?$filter=Dimension_Code eq 'FUNDING SOURCE'&$format=json";
                var httpResponsefundingSource = Credentials.GetOdataData(pageFundingSource);
                using (var streamReader = new StreamReader(httpResponsefundingSource.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var details = JObject.Parse(result);
                    fundingSourceList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["Code"]} - {(string)config["Name"]}", Value = (string)config["Code"] });
                }

                // Get Vote List  
                var voteList = new List<DropdownList>();
                var pageCourses = "DimensionValueList?$filter=Dimension_Code eq 'VOTE'&$format=json";
                var httpResponseVoteList = Credentials.GetOdataData(pageCourses);
                using (var streamReader = new StreamReader(httpResponseVoteList.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var details = JObject.Parse(result);
                    voteList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["Code"]} - {(string)config["Name"]}", Value = (string)config["Code"] });
                }

                claimLine.ListOfGlAccount = glAccountList.Select(x =>
                    new SelectListItem
                    {
                        Text = x.Text,
                        Value = x.Value
                    }).ToList();

                claimLine.ListOfClaimTypes = claimTypesList.Select(x =>
                    new SelectListItem
                    {
                        Text = x.Text,
                        Value = x.Value
                    }).ToList();

                claimLine.ListOfFundingSource = fundingSourceList.Select(x =>
                    new SelectListItem
                    {
                        Text = x.Text,
                        Value = x.Value
                    }).ToList();
                claimLine.ListOfVoteItem = voteList.Select(x =>
                    new SelectListItem
                    {
                        Text = x.Text,
                        Value = x.Value
                    }).ToList();


                return PartialView("PartialViews/NewStaffClaimLine", claimLine);
            }
            catch (Exception ex)
            {
                var erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
            }
        }

        public JsonResult DeleteStaffClaimLine(string code, string lineNo)
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;
                var staffNo = Session["Username"].ToString();
                Credentials.ObjNav.deleteStaffClaimLine(staffNo, code, Convert.ToInt32(lineNo));

                return Json(new { message = "PV line deleted successfully", success = true });
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }


        public JsonResult SubmitClaimLine(ClaimLineViewModel claimLineViewModel)
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;


                var success = Credentials.ObjNav.FnInsertModifyStaffClaimLines(claimLineViewModel.DocNo, claimLineViewModel.GlAccount, claimLineViewModel.VoteItem, claimLineViewModel.FundingSource, claimLineViewModel.Amount, 0, claimLineViewModel.ClaimType, claimLineViewModel.Description);

                return Json(success ? new { message = "Staff Claim line submitted successfully", success = true } : new { message = "Failed to submit Claim line", success = false }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

    }
}