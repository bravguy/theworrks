using iTextSharp.text;
using Latest_Staff_Portal.CustomSecurity;
using Latest_Staff_Portal.Models;
using Latest_Staff_Portal.ViewModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Org.BouncyCastle.Crypto.Tls;
using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using System.Web.Services.Description;
using static iTextSharp.text.pdf.AcroFields;

namespace Latest_Staff_Portal.Controllers
{

    [CustomeAuthentication]
    [CustomAuthorization(Role = "ALLUSERS")]
    public class PurchaseController : Controller
    {
        public ActionResult ApprovedPurchaseRequisitionList()
        {
            try
            {
                if (Session["Username"] == null)
                {
                    return RedirectToAction("Login", "Login");
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                Error erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return View("~/Views/Common/ErrorMessange.cshtml", erroMsg);
            }
        }
        public ActionResult AssignedPurchaseRequisitionList()
        {
            try
            {
                if (Session["Username"] == null)
                {
                    return RedirectToAction("Login", "Login");
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                Error erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return View("~/Views/Common/ErrorMessange.cshtml", erroMsg);
            }
        }
        public PartialViewResult ApprovedPurchaseRequisitionListPartialView(string Type)
        {
            try
            {
                string userId = Session["UserId"].ToString();
                EmployeeView employeeView = Session["EmployeeData"] as EmployeeView;
                List<ApprovedPurchaseRequisitions> ApprovedPurchaseRequisitions = new List<ApprovedPurchaseRequisitions>();
                string empNo = employeeView.No;
                var page = "";
                if (Type == "Assigned")
                {
                    page = $"ApprovedPRN?$filter=Request_By_No eq '{empNo}'and Status eq 'Released' and Notified eq true &$format=json";
                }
                else
                {
                    page = $"ApprovedPRN?$filter=Request_By_No eq '{empNo}'and Status eq 'Released' and  Status eq 'Released' and  Notified eq false &$format=json";
                }


                HttpWebResponse httpResponse = Credentials.GetOdataData(page);

                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var details = JObject.Parse(result);

                    ApprovedPurchaseRequisitions.AddRange(from JObject config in details["value"]
                                                          select new ApprovedPurchaseRequisitions
                                                          {
                                                              Document_Type = (string)config["Document_Type"],
                                                              No = (string)config["No"],
                                                              PRN_Type = (string)config["PRN_Type"],
                                                              Document_Date = (string)config["Document_Date"],
                                                              Location_Code = (string)config["Location_Code"],
                                                              Requisition_Product_Group = (string)config["Requisition_Product_Group"],
                                                              Requester_ID = (string)config["Requester_ID"],
                                                              Request_By_No = (string)config["Request_By_No"],
                                                              Request_By_Name = (string)config["Request_By_Name"],
                                                              Shortcut_Dimension_1_Code = (string)config["Shortcut_Dimension_1_Code"],
                                                              Department_Name = (string)config["Department_Name"],
                                                              Shortcut_Dimension_2_Code = (string)config["Shortcut_Dimension_2_Code"],
                                                              Project_Name = (string)config["Project_Name"],
                                                              Procurement_Plan_ID = (string)config["Procurement_Plan_ID"],
                                                              Purchaser_Code = (string)config["Purchaser_Code"],
                                                              Assigned_Officer = (string)config["Assigned_Officer"],
                                                              Job = (string)config["Job"],
                                                              Job_Task_No = (string)config["Job_Task_No"],
                                                              PP_Planning_Category = (string)config["PP_Planning_Category"],
                                                              Description = (string)config["Description"],
                                                              PP_Total_Budget = (int?)config["PP_Total_Budget"] ?? 0,
                                                              PP_Total_Actual_Costs = (int?)config["PP_Total_Actual_Costs"] ?? 0,
                                                              PP_Solicitation_Type = (string)config["PP_Solicitation_Type"],
                                                              Other_Procurement_Methods = (string)config["Other_Procurement_Methods"],
                                                              PP_Bid_Selection_Method = (string)config["PP_Bid_Selection_Method"],
                                                              PP_Procurement_Method = (string)config["PP_Procurement_Method"],
                                                              PP_Invitation_Notice_Type = (string)config["PP_Invitation_Notice_Type"],
                                                              PP_Preference_Reservation_Code = (string)config["PP_Preference_Reservation_Code"],
                                                              PRN_Conversion_Procedure = (string)config["PRN_Conversion_Procedure"],
                                                              Ordered_PRN = (bool?)config["Ordered_PRN"] ?? false,
                                                              Linked_IFS_No = (string)config["Linked_IFS_No"],
                                                              Linked_LPO_No = (string)config["Linked_LPO_No"],
                                                              Consolidate_PRN = (bool?)config["Consolidate_PRN"] ?? false,
                                                              Consolidate_to_IFS_No = (string)config["Consolidate_to_IFS_No"],
                                                              Status = (string)config["Status"]
                                                          });
                }
                return PartialView(ApprovedPurchaseRequisitions.OrderByDescending(x => x.No));
            }
            catch (Exception ex)
            {
                Error erroMsg = new Error
                {
                    Message = ex.Message
                };
                return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
            }
        }

        public JsonResult SubmitPurchaseRequisition(ApprovedPurchaseRequisitions ApprovedPurchaseRequisitions)
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;
                //var loggedInUser = employee?.UserID;
                var staffNo = Session["Username"].ToString();
                var UserID = employee.UserID;

                if (string.IsNullOrEmpty(staffNo))
                {
                    return Json(new { message = "User session expired. Please login again.", success = false },
                        JsonRequestBehavior.AllowGet);
                }

                var docNo = Credentials.ObjNav.fncreatePurchaseRequisition(staffNo, ApprovedPurchaseRequisitions.Location_Code, ApprovedPurchaseRequisitions.Procurement_Plan_ID, ApprovedPurchaseRequisitions.PP_Planning_Category);                
                Credentials.ObjNav.FnUpdateOpenPurchaseRequisition(docNo, staffNo, ApprovedPurchaseRequisitions.Location_Code, ApprovedPurchaseRequisitions.Procurement_Plan_ID, ApprovedPurchaseRequisitions.PP_Planning_Category, Convert.ToInt32(ApprovedPurchaseRequisitions.Requisition_Product_Group));

                RedirectToAction("PurchaseRequisitionsDocumentView", new { No = docNo });
                return Json(new { message = docNo, success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }
        public JsonResult UpdatePurchaseRequisition(ApprovedPurchaseRequisitions ApprovedPurchaseRequisitions)
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;
                //var loggedInUser = employee?.UserID;
                var staffNo = Session["Username"].ToString();
                var UserID = employee.UserID;

                if (string.IsNullOrEmpty(staffNo))
                {
                    return Json(new { message = "User session expired. Please login again.", success = false },
                        JsonRequestBehavior.AllowGet);
                }


                Credentials.ObjNav.FnUpdateOpenPurchaseRequisition(ApprovedPurchaseRequisitions.No, staffNo, ApprovedPurchaseRequisitions.Location_Code, ApprovedPurchaseRequisitions.Procurement_Plan_ID, ApprovedPurchaseRequisitions.PP_Planning_Category, Convert.ToInt32(ApprovedPurchaseRequisitions.Requisition_Product_Group));

                return Json(new { message = "Purchase requisition header updated successfully!", success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult UpdateApprovedPurchaseRequisition(ApprovedPurchaseRequisitions approvedPurchaseRequisitions)
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;
                //var loggedInUser = employee?.UserID;
                var staffNo = Session["Username"].ToString();
                var UserID = employee.UserID;

                if (string.IsNullOrEmpty(staffNo))
                {
                    return Json(new { message = "User session expired. Please login again.", success = false },
                        JsonRequestBehavior.AllowGet);
                }


                Credentials.ObjNav.FnUpdateApprovedPurchaseRequisition(approvedPurchaseRequisitions.No, staffNo, Convert.ToInt32(approvedPurchaseRequisitions.PP_Invitation_Notice_Type), approvedPurchaseRequisitions.Assigned_Officer, approvedPurchaseRequisitions.PP_Preference_Reservation_Code, Convert.ToInt32(approvedPurchaseRequisitions.PP_Procurement_Method), approvedPurchaseRequisitions.PP_Solicitation_Type);

                return Json(new { message = "Approved Purchase requisition header updated successfully!", success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult PurchaseRequisitionsDocumentView(string No)
        {
            try
            {
                if (Session["Username"] == null)
                {
                    return RedirectToAction("Login", "Login");
                }
                else
                {
                    string StaffNo = Session["Username"].ToString();
                    ApprovedPurchaseRequisitions purchase = new ApprovedPurchaseRequisitions();

                    string page = "ApprovedPRN?$filter=No eq '" + No + "'&format=json";
                    HttpWebResponse httpResponse = Credentials.GetOdataData(page);
                    using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();

                        var details = JObject.Parse(result);
                        foreach (JObject config in details["value"])
                        {

                            purchase.Document_Type = (string)config["Document_Type"];
                            purchase.No = (string)config["No"];
                            purchase.PRN_Type = (string)config["PRN_Type"];
                            purchase.Document_Date = (string)config["Document_Date"];
                            purchase.Location_Code = (string)config["Location_Code"];
                            purchase.Requisition_Product_Group = (string)config["Requisition_Product_Group"];
                            purchase.Requester_ID = (string)config["Requester_ID"];
                            purchase.Request_By_No = (string)config["Request_By_No"];
                            purchase.Request_By_Name = (string)config["Request_By_Name"];
                            purchase.Shortcut_Dimension_1_Code = (string)config["Shortcut_Dimension_1_Code"];
                            purchase.Department_Name = (string)config["Department_Name"];
                            purchase.Shortcut_Dimension_2_Code = (string)config["Shortcut_Dimension_2_Code"];
                            purchase.Project_Name = (string)config["Project_Name"];
                            purchase.Procurement_Plan_ID = (string)config["Procurement_Plan_ID"];
                            purchase.Purchaser_Code = (string)config["Purchaser_Code"];
                            purchase.Assigned_Officer = (string)config["Assigned_Officer"];
                            purchase.Job = (string)config["Job"];
                            purchase.Job_Task_No = (string)config["Job_Task_No"];
                            purchase.PP_Planning_Category = (string)config["PP_Planning_Category"];
                            purchase.Description = (string)config["Description"];
                            purchase.PP_Total_Budget = (int)config["PP_Total_Budget"];
                            purchase.PP_Total_Actual_Costs = (int)config["PP_Total_Actual_Costs"];
                            purchase.PP_Solicitation_Type = (string)config["PP_Solicitation_Type"];
                            purchase.Other_Procurement_Methods = (string)config["Other_Procurement_Methods"];
                            purchase.PP_Bid_Selection_Method = (string)config["PP_Bid_Selection_Method"];
                            purchase.PP_Procurement_Method = (string)config["PP_Procurement_Method"];
                            purchase.PP_Invitation_Notice_Type = (string)config["PP_Invitation_Notice_Type"];
                            purchase.PP_Preference_Reservation_Code = (string)config["PP_Preference_Reservation_Code"];
                            purchase.PRN_Conversion_Procedure = (string)config["PRN_Conversion_Procedure"];
                            purchase.Ordered_PRN = (bool)config["Ordered_PRN"];
                            purchase.Linked_IFS_No = (string)config["Linked_IFS_No"];
                            purchase.Linked_LPO_No = (string)config["Linked_LPO_No"];
                            purchase.Consolidate_PRN = (bool)config["Consolidate_PRN"];
                            purchase.Consolidate_to_IFS_No = (string)config["Consolidate_to_IFS_No"];
                            purchase.Status = (string)config["Status"];
                            purchase.Notified = (bool)config["Notified"];

                        }
                    }



                    #region Purchasers
                    List<DropdownList> Purchasers = new List<DropdownList>();
                    string pagePurchasers = "Purchasers?$format=json";

                    HttpWebResponse httpResponsePurchasers = Credentials.GetOdataData(pagePurchasers);
                    using (var streamReader = new StreamReader(httpResponsePurchasers.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                        var details = JObject.Parse(result);
                        foreach (JObject config in details["value"])
                        {
                            DropdownList dropdownList3 = new DropdownList();
                            dropdownList3.Text = (string)config["Name"] + " - " + (string)config["Code"];
                            dropdownList3.Value = (string)config["Code"];
                            Purchasers.Add(dropdownList3);
                        }
                    }
                    #endregion

                    #region VendorCategory
                    List<DropdownList> VendorCategory = new List<DropdownList>();
                    string pageVendorCategory = "VendorCategory?$format=json";

                    HttpWebResponse httpResponseVendorCategory = Credentials.GetOdataData(pageVendorCategory);
                    using (var streamReader = new StreamReader(httpResponseVendorCategory.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                        var details = JObject.Parse(result);
                        foreach (JObject config in details["value"])
                        {
                            DropdownList dropdownList3 = new DropdownList();
                            dropdownList3.Text = (string)config["Description"] + " - " + (string)config["Code"];
                            dropdownList3.Value = (string)config["Code"];
                            VendorCategory.Add(dropdownList3);
                        }
                    }
                    #endregion

                    #region solicitationType
                    List<DropdownList> SolicitationType = new List<DropdownList>();
                    string pageSolicitationType = "SolicitationType?$format=json";

                    HttpWebResponse httpResponseSolicitationType = Credentials.GetOdataData(pageSolicitationType);
                    using (var streamReader = new StreamReader(httpResponseSolicitationType.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                        var details = JObject.Parse(result);
                        foreach (JObject config in details["value"])
                        {
                            DropdownList dropdownList3 = new DropdownList();
                            dropdownList3.Text = (string)config["Description"] + " - " + (string)config["Code"];
                            dropdownList3.Value = (string)config["Code"];
                            SolicitationType.Add(dropdownList3);
                        }
                    }
                    #endregion


                    purchase.ListOfAssigned_Officer = Purchasers.Select(x =>
                                      new SelectListItem()
                                      {
                                          Text = x.Text,
                                          Value = x.Value
                                      }).ToList();
                    purchase.ListOfPP_Solicitation_Type = SolicitationType.Select(x =>
                                      new SelectListItem()
                                      {
                                          Text = x.Text,
                                          Value = x.Value
                                      }).ToList();
                    purchase.ListOfPP_Preference_Reservation_Code = VendorCategory.Select(x =>
                                      new SelectListItem()
                                      {
                                          Text = x.Text,
                                          Value = x.Value
                                      }).ToList();


                    return View(purchase);
                }
            }
            catch (Exception ex)
            {
                Error erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return View("~/Views/Common/ErrorMessange.cshtml", erroMsg);
            }
        }

        public ActionResult PurchaseRequisitionList()
        {
            try
            {
                if (Session["Username"] == null)
                {
                    return RedirectToAction("Login", "Login");
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                Error erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return View("~/Views/Common/ErrorMessange.cshtml", erroMsg);
            }
        }

        public PartialViewResult PurchaseRequisitionListPartialView()
        {
            var employee = Session["EmployeeData"] as EmployeeView;
            var userId = employee?.UserID;
            var StaffNo = Session["Username"].ToString();
            var rsrceReq = $"PurchaseRequisition?$filter= Request_By_No eq '{StaffNo}'&$orderby=No desc&$format=json";
            var httpResponse = Credentials.GetOdataData(rsrceReq);

            using var streamReader = new StreamReader(httpResponse.GetResponseStream());
            var result = streamReader.ReadToEnd();

            var odataResponse = JsonConvert.DeserializeObject<ODataResponse<PurchaseRequisition>>(result);
            var prns = odataResponse?.Value ?? [];

            return PartialView(prns);
        }

        public ActionResult PrnDocumentView(string No)
        {
            var rsrceReq = $"PurchaseRequisition?$filter=No eq '{No}'&$format=json";
            var httpResponse = Credentials.GetOdataData(rsrceReq);
            using var docStreamReader = new StreamReader(httpResponse.GetResponseStream());
            var docResult = docStreamReader.ReadToEnd();
            var odataResponse = JsonConvert.DeserializeObject<ODataResponse<PurchaseRequisition>>(docResult);
            var prnDocumentrequest = odataResponse?.Value?.FirstOrDefault();

            var CurrentProcurementPlan = GetActiveProcurementPlan();

            #region Location_Code
            List<DropdownList> Location_Code = new List<DropdownList>();
            string pageLocation_Code = "Locations?$format=json";

            HttpWebResponse httpResponseLocation_Code = Credentials.GetOdataData(pageLocation_Code);
            using (var streamReader = new StreamReader(httpResponseLocation_Code.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                var details = JObject.Parse(result);
                foreach (JObject config in details["value"])
                {
                    DropdownList dropdownList3 = new DropdownList();
                    dropdownList3.Text = (string)config["Name"] + " (" + (string)config["Code"] + ")";
                    dropdownList3.Value = (string)config["Code"];
                    Location_Code.Add(dropdownList3);
                }
            }
            #endregion



            #region ProcurementPlanID
            List<DropdownList> ProcurementPlanID = new List<DropdownList>();
            string pagePP = "ProcurementPlan?$format=json";

            HttpWebResponse httpResponsePP = Credentials.GetOdataData(pagePP);
            using (var streamReader = new StreamReader(httpResponsePP.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                var details = JObject.Parse(result);
                foreach (JObject config in details["value"])
                {
                    DropdownList dropdownList3 = new DropdownList();
                    dropdownList3.Text = (string)config["Description"] + " (" + (string)config["Code"] + ")";
                    dropdownList3.Value = (string)config["Code"];
                    ProcurementPlanID.Add(dropdownList3);
                }
            }
            #endregion


            #region PP_Planning_Category
            List<DropdownList> Category = new List<DropdownList>();
            /* string pageCategory = "ProcurementPlanLines?$format=json";*/
            string pageCategory = $"ProcurementPlanLines?$filter= Procurement_Plan_ID eq '{CurrentProcurementPlan}'&$format=json";


            HttpWebResponse httpResponseCategory = Credentials.GetOdataData(pageCategory);
            using (var streamReader = new StreamReader(httpResponseCategory.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                var details = JObject.Parse(result);
                foreach (JObject config in details["value"])
                {
                    DropdownList dropdownList3 = new DropdownList();
                    dropdownList3.Text = (string)config["Procurement_Plan_ID"] + " (" + (string)config["Description"] + ")";
                    dropdownList3.Value = (string)config["Planning_Category"];
                    Category.Add(dropdownList3);
                }
            }
            #endregion

            prnDocumentrequest.ListOfLocation_Code = Location_Code.Select(x =>
                              new SelectListItem()
                              {
                                  Text = x.Text,
                                  Value = x.Value
                              }).ToList();





            prnDocumentrequest.ListOfProcurementPlans = ProcurementPlanID.Select(x =>
                          new SelectListItem()
                          {
                              Text = x.Text,
                              Value = x.Value
                          }).ToList();



            prnDocumentrequest.ListOfPP_Planning_Category = Category.Select(x =>
                        new SelectListItem()
                        {
                            Text = x.Text,
                            Value = x.Value
                        }).ToList();

            return View("PrnDocumentView", prnDocumentrequest);
        }
        public PartialViewResult PurchaseRequisitionLinesPartialView(string Document_No, String Status)
        {
            try
            {
                ViewBag.Status = Status;
                //string pageLine = $"PrnLines?$filter=Document_No eq '{Document_No}'&$format=json";
                string pageLine = $"PrnLines?$filter=Document_No eq '{Document_No}'&$format=json";
                var httpResponse = Credentials.GetOdataData(pageLine);
                using var streamReader = new StreamReader(httpResponse.GetResponseStream());
                var result = streamReader.ReadToEnd();
                var odataResponse = JsonConvert.DeserializeObject<ODataResponse<PurchaseRequisitionLine>>(result);

                // Fix: Pass the entire list instead of just the first item
                var prnLines = odataResponse?.Value ?? new List<PurchaseRequisitionLine>();

                return PartialView("PartialViews/PurchaseRequisitionLinesPartialView", prnLines);
            }
            catch (Exception ex)
            {
                // Handle and return error view
                Error erroMsg = new Error
                {
                    Message = ex.Message
                };
                return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
            }
        }
        
        public PartialViewResult ApprovedPRNLinesPartialView(string Document_No, bool Notified)
        {
            try
            {
                ViewBag.Notified = Notified;
                ViewBag.DocNo = Document_No;
                string pageLine = $"ApprovedPrnLines?$filter=Document_No eq '{Document_No}'&$format=json";
                var httpResponse = Credentials.GetOdataData(pageLine);
                using var streamReader = new StreamReader(httpResponse.GetResponseStream());
                var result = streamReader.ReadToEnd();
                var odataResponse = JsonConvert.DeserializeObject<ODataResponse<AppprovedPrnLines>>(result);

                // Fix: Pass the entire list instead of just the first item
                var prnLines = odataResponse?.Value ?? new List<AppprovedPrnLines>();

                return PartialView("PartialViews/ApprovedPRNLinesPartialView", prnLines);
            }
            catch (Exception ex)
            {
                // Handle and return error view
                Error erroMsg = new Error
                {
                    Message = ex.Message
                };
                return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
            }
        }

        public ActionResult NewPurchaseRequisition(ApprovedPurchaseRequisitions ApprovedPurchaseRequisitions)
        {
            try
            {
                if (Session["Username"] == null)
                {
                    return RedirectToAction("Login", "Login");
                }
                else
                {
                    ApprovedPurchaseRequisitions purchaseReq = new ApprovedPurchaseRequisitions();
                    Session["httpResponse"] = null;
                    EmployeeView employeeView = Session["EmployeeData"] as EmployeeView;
                    var CurrentProcurementPlan = GetActiveProcurementPlan();
                    purchaseReq.Procurement_Plan_ID = CurrentProcurementPlan;

                    /* purchaseReq.EmployeeNo = employeeView.No;
                       purchaseReq.EmployeeName = employeeView.FullName;*/

                    #region Location_Code
                    List<DropdownList> Location_Code = new List<DropdownList>();
                    string pageLocation_Code = "Locations?$format=json";

                    HttpWebResponse httpResponseLocation_Code = Credentials.GetOdataData(pageLocation_Code);
                    using (var streamReader = new StreamReader(httpResponseLocation_Code.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                        var details = JObject.Parse(result);
                        foreach (JObject config in details["value"])
                        {
                            DropdownList dropdownList3 = new DropdownList();
                            dropdownList3.Text = (string)config["Name"] + " (" + (string)config["Code"] + ")";
                            dropdownList3.Value = (string)config["Code"];
                            Location_Code.Add(dropdownList3);
                        }
                    }
                    #endregion



                    #region ProcurementPlanID
                    List<DropdownList> ProcurementPlanID = new List<DropdownList>();
                    string pagePP = "ProcurementPlan?$format=json";

                    HttpWebResponse httpResponsePP = Credentials.GetOdataData(pagePP);
                    using (var streamReader = new StreamReader(httpResponsePP.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                        var details = JObject.Parse(result);
                        foreach (JObject config in details["value"])
                        {
                            DropdownList dropdownList3 = new DropdownList();
                            dropdownList3.Text = (string)config["Description"] + " (" + (string)config["Code"] + ")";
                            dropdownList3.Value = (string)config["Code"];
                            ProcurementPlanID.Add(dropdownList3);
                        }
                    }
                    #endregion


                    #region PP_Planning_Category
                    List<DropdownList> Category = new List<DropdownList>();
                    /* string pageCategory = "ProcurementPlanLines?$format=json";*/
                    string pageCategory = $"ProcurementPlanLines?$filter= Procurement_Plan_ID eq '{CurrentProcurementPlan}'&$format=json";


                    HttpWebResponse httpResponseCategory = Credentials.GetOdataData(pageCategory);
                    using (var streamReader = new StreamReader(httpResponseCategory.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                        var details = JObject.Parse(result);
                        foreach (JObject config in details["value"])
                        {
                            DropdownList dropdownList3 = new DropdownList();
                            dropdownList3.Text = (string)config["Procurement_Plan_ID"] + " (" + (string)config["Description"] + ")";
                            dropdownList3.Value = (string)config["Planning_Category"];
                            Category.Add(dropdownList3);
                        }
                    }
                    #endregion




                    //purchaseReq.No = Document_No;

                    purchaseReq.ListOfLocation_Code = Location_Code.Select(x =>
                                      new SelectListItem()
                                      {
                                          Text = x.Text,
                                          Value = x.Value
                                      }).ToList();





                    purchaseReq.ListOfProcurementPlans = ProcurementPlanID.Select(x =>
                                  new SelectListItem()
                                  {
                                      Text = x.Text,
                                      Value = x.Value
                                  }).ToList();



                    purchaseReq.ListOfPP_Planning_Category = Category.Select(x =>
                                new SelectListItem()
                                {
                                    Text = x.Text,
                                    Value = x.Value
                                }).ToList();





                    return PartialView("~/Views/Purchase/PartialViews/NewPurchaseRequisition.cshtml", purchaseReq);

                }
            }

            catch (Exception ex)
            {
                Error erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
            }
        }

        public ActionResult UpdatePurchaseRequisitionHeader(string Document_No)
        {
            try
            {
                if (Session["Username"] == null)
                {
                    return RedirectToAction("Login", "Login");
                }
                else
                {
                    PurchaseRequisition purchaseReq = new PurchaseRequisition();
                    Session["httpResponse"] = null;
                    EmployeeView employeeView = Session["EmployeeData"] as EmployeeView;
                    var CurrentProcurementPlan = GetActiveProcurementPlan();
                    purchaseReq.Procurement_Plan_ID = CurrentProcurementPlan;

                    var rsrceReq = $"PurchaseRequisition?$filter=No eq '{Document_No}'&$format=json";
                    var httpResponse = Credentials.GetOdataData(rsrceReq);
                    using var streamReader1 = new StreamReader(httpResponse.GetResponseStream());
                    var result1 = streamReader1.ReadToEnd();
                    var odataResponse = JsonConvert.DeserializeObject<ODataResponse<PurchaseRequisition>>(result1);
                    var prnDocumentrequest = odataResponse?.Value?.FirstOrDefault();

                    purchaseReq.Requester_ID = prnDocumentrequest.Requester_ID;
                    purchaseReq.Request_By_Name = prnDocumentrequest.Request_By_Name;
                    purchaseReq.PRN_Type = prnDocumentrequest.PRN_Type;
                    purchaseReq.Shortcut_Dimension_2_Code = prnDocumentrequest.Shortcut_Dimension_2_Code;
                    purchaseReq.Requisition_Product_Group = prnDocumentrequest.Requisition_Product_Group;
                    purchaseReq.PP_Planning_Category = prnDocumentrequest.PP_Planning_Category;

                    #region Location_Code
                    List<DropdownList> Location_Code = new List<DropdownList>();
                    string pageLocation_Code = "Locations?$format=json";

                    HttpWebResponse httpResponseLocation_Code = Credentials.GetOdataData(pageLocation_Code);
                    using (var streamReader = new StreamReader(httpResponseLocation_Code.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                        var details = JObject.Parse(result);
                        foreach (JObject config in details["value"])
                        {
                            DropdownList dropdownList3 = new DropdownList();
                            dropdownList3.Text = (string)config["Name"] + " (" + (string)config["Code"] + ")";
                            dropdownList3.Value = (string)config["Code"];
                            Location_Code.Add(dropdownList3);
                        }
                    }
                    #endregion



                    #region ProcurementPlanID
                    List<DropdownList> ProcurementPlanID = new List<DropdownList>();
                    string pagePP = "ProcurementPlan?$format=json";

                    HttpWebResponse httpResponsePP = Credentials.GetOdataData(pagePP);
                    using (var streamReader = new StreamReader(httpResponsePP.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                        var details = JObject.Parse(result);
                        foreach (JObject config in details["value"])
                        {
                            DropdownList dropdownList3 = new DropdownList();
                            dropdownList3.Text = (string)config["Description"] + " (" + (string)config["Code"] + ")";
                            dropdownList3.Value = (string)config["Code"];
                            ProcurementPlanID.Add(dropdownList3);
                        }
                    }
                    #endregion


                    #region PP_Planning_Category
                    List<DropdownList> Category = new List<DropdownList>();
                    /* string pageCategory = "ProcurementPlanLines?$format=json";*/
                    string pageCategory = $"ProcurementPlanLines?$filter= Procurement_Plan_ID eq '{CurrentProcurementPlan}'&$format=json";


                    HttpWebResponse httpResponseCategory = Credentials.GetOdataData(pageCategory);
                    using (var streamReader = new StreamReader(httpResponseCategory.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                        var details = JObject.Parse(result);
                        foreach (JObject config in details["value"])
                        {
                            DropdownList dropdownList3 = new DropdownList();
                            dropdownList3.Text = (string)config["Procurement_Plan_ID"] + " (" + (string)config["Description"] + ")";
                            dropdownList3.Value = (string)config["Planning_Category"];
                            Category.Add(dropdownList3);
                        }
                    }
                    #endregion




                    //purchaseReq.No = Document_No;

                    purchaseReq.ListOfLocation_Code = Location_Code.Select(x =>
                                      new SelectListItem()
                                      {
                                          Text = x.Text,
                                          Value = x.Value
                                      }).ToList();





                    purchaseReq.ListOfProcurementPlans = ProcurementPlanID.Select(x =>
                                  new SelectListItem()
                                  {
                                      Text = x.Text,
                                      Value = x.Value
                                  }).ToList();



                    purchaseReq.ListOfPP_Planning_Category = Category.Select(x =>
                                new SelectListItem()
                                {
                                    Text = x.Text,
                                    Value = x.Value
                                }).ToList();





                    return PartialView("~/Views/Purchase/PartialViews/UpdatePurchaseRequisition.cshtml", purchaseReq);

                }
            }

            catch (Exception ex)
            {
                Error erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
            }
        }

        private string GetActiveProcurementPlan()
        {
            try
            {
                var procurementPlanId = Credentials.ObjNav.GetActiveProcurementPlan();
                return procurementPlanId;
            }
            catch (Exception ex)
            {
                throw new Exception("Error retrieving Procurement Plan ID: " + ex.Message);
            }
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult SendPurchaseReqDocForApproval(String Document_No)
        {
            try
            {
                EmployeeView employeeView = Session["EmployeeData"] as EmployeeView;
                string Responsible_Employee_No = employeeView.No;
                string UserID = employeeView.UserID;

                Credentials.ObjNav.sendPurchaseRequisitionApproval(Responsible_Employee_No, Document_No);
                Credentials.ObjNav.UpdateApprovalEntrySenderID(38, Document_No, UserID);
                string message = "Purchase Requisition Sent For Approval successfully";
                return Json(new { message = message, success = true }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false }, JsonRequestBehavior.AllowGet);
            }
        }
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult NotifySupplyChainOfficer(String Document_No)
        {
            try
            {
                EmployeeView employeeView = Session["EmployeeData"] as EmployeeView;
                string Responsible_Employee_No = employeeView.No;
                string UserID = employeeView.UserID;

                Credentials.ObjNav.FnNotifySupplyChain(Document_No);
                string message = "Supply Chain Officer Notified Successfully";
                return Json(new { message = message, success = true }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false }, JsonRequestBehavior.AllowGet);
            }
        }
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult CreateLPO(String Document_No)
        {
            try
            {
                EmployeeView employeeView = Session["EmployeeData"] as EmployeeView;
                string Responsible_Employee_No = employeeView.No;
                string UserID = employeeView.UserID;

                Credentials.ObjNav.FnCreateLPO(Document_No, UserID);
                string Redirect = "LPO created successfully";
                return Json(new { message = Redirect, success = true }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false }, JsonRequestBehavior.AllowGet);
            }
        }
         [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult CreateInvitationNotice(String Document_No)
        {
            try
            {
                EmployeeView employeeView = Session["EmployeeData"] as EmployeeView;
                string Responsible_Employee_No = employeeView.No;
                string UserID = employeeView.UserID;

                Credentials.ObjNav.FnCreateInvitationNotice(Document_No, UserID);
                string Redirect = "invitation notice created successfully";
                return Json(new { message = Redirect, success = true }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false }, JsonRequestBehavior.AllowGet);
            }
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult CancelPurchaseReqApprovalRequest(String Document_No)
        {
            try
            {
                EmployeeView employeeView = Session["EmployeeData"] as EmployeeView;
                string Responsible_Employee_No = employeeView.No;
                string UserID = employeeView.UserID;

                Credentials.ObjNav.fnCancelPurchaseRequisitionApproval(Responsible_Employee_No, Document_No);
                string Redirect = "Store Requisition Approval Request Cancelled";
                return Json(new { message = Redirect, success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult NewPrnLine(string Document_No, string Procurement_Plan_ID, string Procurement_Plan_Category, string Requisition_Product_Group)
        {
            try
            {
                if (Session["Username"] == null)
                {
                    return RedirectToAction("Login", "Login");
                }

                var employee = Session["EmployeeData"] as EmployeeView;
                var prnLine = new PrnLineViewModel();
                Session["httpResponse"] = null;

                prnLine.No = Document_No;
                prnLine.Requisition_Product_Group = Requisition_Product_Group;
                prnLine.PlanningCategory = Convert.ToInt32(Procurement_Plan_Category);

                prnLine.ListOfItemFaNo = new List<SelectListItem>
                {
                    new SelectListItem { Text = "--Select Item FaNo--", Value = "" }
                };

                return PartialView("PartialViews/NewPrnLine", prnLine);
            }
            catch (Exception ex)
            {
                var erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
            }
        }

        public JsonResult SubmitPrnLine(PrnLineViewModel prnLineViewModel)
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;
                int RequisitionGroup = 0;

                if (prnLineViewModel.Requisition_Product_Group == "Goods")
                {
                    RequisitionGroup = 0;
                }
                else if (prnLineViewModel.Requisition_Product_Group == "Services")
                {
                    RequisitionGroup = 1;
                }
                else if (prnLineViewModel.Requisition_Product_Group == "Works")
                {
                    RequisitionGroup = 2;
                }


                if (prnLineViewModel.FaNo == null)
                {
                    prnLineViewModel.FaNo = "";
                }

                var success = Credentials.ObjNav.FncreatePurchaseReqLine(prnLineViewModel.No, prnLineViewModel.Quantity, prnLineViewModel.Item, RequisitionGroup, prnLineViewModel.FaNo, prnLineViewModel.TechnicalSpecification, prnLineViewModel.DirectUnitCost);

                return Json(success ? new { message = "PRN line submitted successfully", success = true } : new { message = "Failed to submit PRN line", success = false }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetItemsFaNo(string Item_Category, string planning_Category)
        {
            try
            {
                var pageItemsCategory = "";
                #region ItemsLookup
                List<DropdownList> ItemsLookup = new List<DropdownList>();

                if (Item_Category == "2")
                {
                    pageItemsCategory = $"Items?$filter=Item_Category_Code eq '{planning_Category}'";
                }
                else if (Item_Category == "3")
                {
                    pageItemsCategory = $"FixedAssets?$filter=Procurement_Category eq '{planning_Category}'";
                }
                else
                {
                    pageItemsCategory = "";
                }

                if (pageItemsCategory == "")
                {
                    return Json(new
                    {
                        ListOfItemFaNo = new List<SelectListItem>
                        {
                            new SelectListItem { Text = "No FaNos Found found for the selected Item", Value = "" }
                        },
                        success = true
                    }, JsonRequestBehavior.AllowGet);
                }

                HttpWebResponse httpResponseItems = Credentials.GetOdataData(pageItemsCategory);
                using (var streamReader = new StreamReader(httpResponseItems.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var details = JObject.Parse(result);
                    foreach (JObject config in details["value"])
                    {
                        DropdownList dropdownList3 = new DropdownList();
                        dropdownList3.Text = (string)config["Description"] + " - " + (string)config["No"];
                        dropdownList3.Value = (string)config["No"];
                        ItemsLookup.Add(dropdownList3);
                    }
                }
                #endregion
                // Create and return the JSON result
                var response = new
                {
                    ListOfItemFaNo = ItemsLookup.Select(x => new SelectListItem
                    {
                        Text = x.Text,
                        Value = x.Value
                    }).ToList(),
                    success = true
                };
                return Json(response, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false }, JsonRequestBehavior.AllowGet);
            }

        }

        public JsonResult DeletePRNLine(string code, string lineNo)
        {
            try
            {
                Credentials.ObjNav.deletePurchaseRequisitionLines(Convert.ToInt32(lineNo), code);

                return Json(new { message = "PRN line deleted successfully", success = true });
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult UpdateApprovedPRNLine(int LineNo, decimal AwardedQuantity, decimal AwardedUnitCost, string ContractNoToPay, string DocNo, bool LineSelected)
        {
            try
            {
                // Validate input
                if (AwardedQuantity < 0 || AwardedUnitCost < 0)
                {
                    return Json(new { success = false, message = "Awarded Quantity or Awarded Unit Cost amount cannot be negative." });
                }


                Credentials.ObjNav.FnupdateRequisitionLines(LineNo, DocNo, AwardedUnitCost, AwardedQuantity, ContractNoToPay, LineSelected);

                return Json(new { message = "Approved PRN lines updated successfully", success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

                return Json(new { success = false, message = ex.Message });
            }
        }


    }
}