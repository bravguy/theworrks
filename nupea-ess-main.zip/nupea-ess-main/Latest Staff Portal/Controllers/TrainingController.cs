using Latest_Staff_Portal.Models;
using Latest_Staff_Portal.ViewModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Mvc;

namespace Latest_Staff_Portal.Controllers;

public class TrainingController : Controller
{
    /// <summary>
    /// ///Training Needs///
    /// </summary>
    /// <returns></returns>
    public ActionResult TrainingNeeds()
    {
        try
        {
            if (Session["Username"] == null)
                return RedirectToAction("Login", "Login");
            return View();
        }
        catch (Exception ex)
        {
            var erroMsg = new Error();
            erroMsg.Message = ex.Message;
            return View("~/Views/Common/ErrorMessange.cshtml", erroMsg);
        }
    }
    public PartialViewResult TrainingNeedsList()
    {
        var employee = Session["EmployeeData"] as EmployeeView;
        var userId = employee?.UserID;
        var StaffNo = Session["Username"].ToString();
        var rsrceReq = $"TrainingNeedRequests?$filter=Employee_No eq '{StaffNo}'&$format=json";
        var httpResponse = Credentials.GetOdataData(rsrceReq);

        using var streamReader = new StreamReader(httpResponse.GetResponseStream());
        var result = streamReader.ReadToEnd();

        var odataResponse = JsonConvert.DeserializeObject<ODataResponse<TrainingNeedRequests>>(result);
        var trainingNeedRequests = odataResponse?.Value ?? [];

        return PartialView("Partial Views/TrainingNeedsList", trainingNeedRequests);
    }

    public ActionResult TrainingNeedsDocumentView(string code)
    {
        var rsrceReq = $"TrainingNeedRequests?$filter=Code eq '{code}'&$format=json";
        var httpResponse = Credentials.GetOdataData(rsrceReq);
        using var streamReader = new StreamReader(httpResponse.GetResponseStream());
        var result = streamReader.ReadToEnd();
        var odataResponse = JsonConvert.DeserializeObject<ODataResponse<TrainingNeedRequests>>(result);
        var trainingNeedRequest = odataResponse?.Value?.FirstOrDefault();
        return View("TrainingNeedsDocumentView", trainingNeedRequest);
    }

    public PartialViewResult TrainingEvaluationListPartialView()
    {
        var employee = Session["EmployeeData"] as EmployeeView;
        var userId = employee?.UserID;
        var StaffNo = Session["Username"].ToString();
        var page = $"TrainingAssessment?$filter=Employee_No eq '{StaffNo}'&$format=json";
        var httpResponse = Credentials.GetOdataData(page);

        using var streamReader = new StreamReader(httpResponse.GetResponseStream());
        var result = streamReader.ReadToEnd();

        var odataResponse = JsonConvert.DeserializeObject<ODataResponse<TrainingEvaluation>>(result);
        var trainingEvaluations = odataResponse?.Value ?? [];

        return PartialView("Partial Views/TrainingEvaluationListPartialView", trainingEvaluations);
    }
    public ActionResult TrainingEvaluationDocumentView(string docNo)
    {
        var rsrceReq = $"TrainingAssessment?$filter=No eq '{docNo}'&$format=json";
        var httpResponse = Credentials.GetOdataData(rsrceReq);
        using var streamReader = new StreamReader(httpResponse.GetResponseStream());
        var result = streamReader.ReadToEnd();
        var odataResponse = JsonConvert.DeserializeObject<ODataResponse<TrainingEvaluation>>(result);
        var trainingEvaluations = odataResponse?.Value?.FirstOrDefault();
        return View("TrainingEvaluationDocumentView", trainingEvaluations);
    }
    
    public PartialViewResult TrainingNeedsLines(string trainingHeaderNo,string status)
    {
        ViewBag.Status = status;
        var employee = Session["EmployeeData"] as EmployeeView;

        var rsrceReq = $"TrainingNeedsLines?$filter=Document_No eq '{trainingHeaderNo}'&$format=json";

        var httpResponse = Credentials.GetOdataData(rsrceReq);

        using var streamReader = new StreamReader(httpResponse.GetResponseStream());
        var result = streamReader.ReadToEnd();

        var odataResponse = JsonConvert.DeserializeObject<ODataResponse<TrainingNeedsLines>>(result);
        var trainingNeedsLines = odataResponse?.Value ?? [];

        return PartialView("Partial Views/TrainingNeedsLines", trainingNeedsLines);
    }
    public ActionResult TrainingCostLines(string code,string course)
    {
        var rsrceReq = $"TrainingCost?$filter=Training_ID eq '{code}' and Course_ID eq '{course}' &$format=json";
        var httpResponse = Credentials.GetOdataData(rsrceReq);
        using var streamReader = new StreamReader(httpResponse.GetResponseStream());
        var result = streamReader.ReadToEnd();
        var odataResponse = JsonConvert.DeserializeObject<ODataResponse<TrainingCost>>(result);
        var trainingCosts = odataResponse?.Value ?? [];
        return View("Partial Views/TrainingCosts", trainingCosts);
    }
    public ActionResult NewTrainingLine(string docNo, string empNo = "")
    {
        try
        {
            if (Session["Username"] == null)
            {
                return RedirectToAction("Login", "Login");
            }

            var employee = Session["EmployeeData"] as EmployeeView;
            var trainingLine = new TrainingLineViewModel();
            Session["httpResponse"] = null;

            trainingLine.DocumentNo = docNo;
            

            // Get Training Domains List
            var domainsList = new List<DropdownList>();
            var pageDomains = "TrainingDomains?$filter=Synched eq true&$format=json";
            var httpResponseDomains = Credentials.GetOdataData(pageDomains);
            using (var streamReader = new StreamReader(httpResponseDomains.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                var details = JObject.Parse(result);
                domainsList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["Code"]} - {(string)config["Description"]}", Value = (string)config["Code"] });
            }

            // Get Course Providers List
            var providersList = new List<DropdownList>();
            var pageProviders = "vendorlist?$filter=Trainer eq true&$format=json";
            var httpResponseProviders = Credentials.GetOdataData(pageProviders);
            using (var streamReader = new StreamReader(httpResponseProviders.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                var details = JObject.Parse(result);
                providersList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["Name"]}", Value = (string)config["No"] });
            }

            // Get Courses List  
            var coursesList = new List<DropdownList>();
            var pageCourses = "CourseList?$filter=Blocked eq false&$format=json";
            var httpResponseCourses = Credentials.GetOdataData(pageCourses);
            using (var streamReader = new StreamReader(httpResponseCourses.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                var details = JObject.Parse(result);
                coursesList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["Code"]} - {(string)config["Descritpion"]}", Value = (string)config["Code"] });
            }

            trainingLine.ListOfDomains = domainsList.Select(x =>
                new SelectListItem
                {
                    Text = x.Text,
                    Value = x.Value
                }).ToList();

            trainingLine.ListOfProviders = providersList.Select(x =>
                new SelectListItem
                {
                    Text = x.Text,
                    Value = x.Value
                }).ToList();

            trainingLine.ListOfCourses = coursesList.Select(x =>
                new SelectListItem
                {
                    Text = x.Text,
                    Value = x.Value
                }).ToList();

            return PartialView("Partial Views/NewTrainingLine", trainingLine);
        }
        catch (Exception ex)
        {
            var erroMsg = new Error();
            erroMsg.Message = ex.Message;
            return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
        }
    }

    public ActionResult NewEvaluationLine(string docNo, string empNo = "")
    {
        try
        {
            if (Session["Username"] == null)
            {
                return RedirectToAction("Login", "Login");
            }
            var trainingEvaluation = new TrainingEvaluationLine();
            trainingEvaluation.Training_Evaluation_No = docNo;

            // Get Training Categories List
            var categoriesList = new List<DropdownList>();
            var pageCategories = "EvaluationCategorySetup?$filter=Rating_Category eq 'Self'&$format=json";
            var httpResponseDomains = Credentials.GetOdataData(pageCategories);
            using (var streamReader = new StreamReader(httpResponseDomains.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                var details = JObject.Parse(result);
                categoriesList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["Code"]} - {(string)config["Description"]}", Value = (string)config["Code"] });
            }

            trainingEvaluation.ListOfCategories = categoriesList.Select(x =>
                new SelectListItem
                {
                    Text = x.Text,
                    Value = x.Value
                }).ToList();
            return PartialView("Partial Views/NewTrainingEvaluationLine", trainingEvaluation);
        }
        catch (Exception ex)
        {
            var erroMsg = new Error();
            erroMsg.Message = ex.Message;
            return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
        }
    }

    public JsonResult GenerateEvaluationReport(string DocNo)
    {
        try
        {
            string staffNo = Session["Username"].ToString();
            string message = "";
            bool success = false, view = false;

            message = Credentials.ObjNav.fnGenerateTrainingEvaluationReport(DocNo);
            if (message == "")
            {
                success = false;
                message = "File Not Found";
            }
            else
            {
                success = true;
            }
            return Json(new { message = message, success, view }, JsonRequestBehavior.AllowGet);
        }
        catch (Exception ex)
        {
            return Json(new { message = ex.Message, success = false }, JsonRequestBehavior.AllowGet);
        }
    }
    public ActionResult NewTrainingCostLine(string docNo, string courseId = "")
    {
        try
        {
            if (Session["Username"] == null)
            {
                return RedirectToAction("Login", "Login");
            }

            var trainingCost = new TrainingCostViewModel();

            trainingCost.DocumentNo = docNo;

            var costCategoriesList = new List<DropdownList>
            {
                new DropdownList { Text = "Procurable", Value = "0" },
                new DropdownList { Text = "Other Costs", Value = "1" }
            };
            var procurableItemsList = new List<DropdownList>();
            var pageProcurable = "HRModelsList?$filter=Type eq 'Training Item Cost'&$format=json";
            var httpResponseProcurable = Credentials.GetOdataData(pageProcurable);
            using (var streamReader = new StreamReader(httpResponseProcurable.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                var details = JObject.Parse(result);
                procurableItemsList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["Code"]} - {(string)config["Item_Description"]}", Value = (string)config["Item_Code"] });
            }


            ViewBag.Course = courseId;
            trainingCost.CourseID = courseId;

            ViewBag.DsaUnitCost = getDSAUnitCost(trainingCost);

            trainingCost.ListOfCostCategories = costCategoriesList.Select(x =>
                new SelectListItem
                {
                    Text = x.Text,
                    Value = x.Value
                }).ToList();

            trainingCost.ListOfOtherCostItems = procurableItemsList.Select(x =>
                new SelectListItem
                {
                    Text = x.Text,
                    Value = x.Value
                }).ToList();

            return PartialView("Partial Views/NewTrainingCostLine", trainingCost);
        }
        catch (Exception ex)
        {
            var erroMsg = new Error();
            erroMsg.Message = ex.Message;
            return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
        }
    }


    public PartialViewResult TrainingEvaluationLines(string trainingHeaderNo, string status)
    {
        ViewBag.Status = status;
        var employee = Session["EmployeeData"] as EmployeeView;

        var rsrceReq = $"SelfTrainingImpactAssessment?$filter=Training_Evaluation_No eq '{trainingHeaderNo}'&$format=json";

        var httpResponse = Credentials.GetOdataData(rsrceReq);

        using var streamReader = new StreamReader(httpResponse.GetResponseStream());
        var result = streamReader.ReadToEnd();

        var odataResponse = JsonConvert.DeserializeObject<ODataResponse<TrainingEvaluationLine>>(result);
        var trainingEvaluationLines = odataResponse?.Value ?? [];

        return PartialView("Partial Views/TrainingEvaluationLines", trainingEvaluationLines);
    }

    public JsonResult GetCoursesByDomain(string domainId)
    {
        try
        {
            var coursesList = new List<DropdownList>();
            var pageCourses = $"CourseList?$filter=Domain eq '{domainId}'&$format=json";
            var httpResponse = Credentials.GetOdataData(pageCourses);

            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                var details = JObject.Parse(result);
                coursesList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["Code"]} - {(string)config["Descritpion"]}", Value = (string)config["Code"] });
            }

            var selectListItems = coursesList.Select(x => new { Value = x.Value, Text = x.Text }).ToList();

            return Json(new { success = true, courses = selectListItems }, JsonRequestBehavior.AllowGet);
        }
        catch (Exception ex)
        {
            return Json(new { success = false, message = ex.Message.Replace("'", "") }, JsonRequestBehavior.AllowGet);
        }
    }
    public JsonResult CreateTrainingNeedsRequest()
    {
        try
        {
            var employee = Session["EmployeeData"] as EmployeeView;
            //var loggedInUser = employee?.UserID;
            var loggedInUser = Session["UserID"].ToString();

            if (string.IsNullOrEmpty(loggedInUser))
            {
                return Json(new { message = "User session expired. Please login again.", success = false },
                    JsonRequestBehavior.AllowGet);
            }

            var docNo = Credentials.ObjNav.fnCreateNeedsRequest(loggedInUser);

            return Json(new { message = docNo, success = true }, JsonRequestBehavior.AllowGet);
        }
        catch (Exception ex)
        {
            return Json(new { message = ex.Message.Replace("'", ""), success = false },
                JsonRequestBehavior.AllowGet);
        }
    }
    public JsonResult SubmitTrainingLine(TrainingLine trainingLine)
    {
        try
        {
            var employee = Session["EmployeeData"] as EmployeeView;

            if (trainingLine.Points == null)
            {
                trainingLine.Points = 0;
            }

            var success = Credentials.ObjNav.FnInsertTrainingLines(
                trainingLine.DocNo,
                employee?.No,
                trainingLine.DomainId,
                trainingLine.CourseID,
                Convert.ToInt32(trainingLine.Points),
                trainingLine.CourseProvider,
                trainingLine.StartDate,
                trainingLine.EndDate
            );

            return Json(success ? new { message = "Training line submitted successfully", success = true } : new { message = "Failed to submit training line", success = false }, JsonRequestBehavior.AllowGet);
        }
        catch (Exception ex)
        {
            return Json(new { message = ex.Message.Replace("'", ""), success = false },
                JsonRequestBehavior.AllowGet);
        }
    }

    public PartialViewResult NewTrainingEvaluation()
    {
        try
        {
            var employee = Session["EmployeeData"] as EmployeeView;
            var trainingEvaluation = new TrainingEvaluationViewModel();
            var StaffNo = Session["Username"].ToString();

            //trainingLine.DocumentNo = docNo;


            // Get Training Domains List
            var trainigApplicationList = new List<DropdownList>();
            var trainingApplication = $"TrainingRequisition?$filter=Employee_No eq '{StaffNo}' and Status eq 'Approved'&$format=json";
            //var trainingApplication = $"TrainingApplications";
            var httpResponseDomains = Credentials.GetOdataData(trainingApplication);
            using (var streamReader = new StreamReader(httpResponseDomains.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                var details = JObject.Parse(result);
                trainigApplicationList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["Code"]} - {(string)config["Description"]}", Value = (string)config["Code"] });
            }
            trainingEvaluation.trainigApplicationList = trainigApplicationList.Select(x =>
                new SelectListItem
                {
                    Text = x.Text,
                    Value = x.Value
                }).ToList();

            return PartialView("Partial Views/NewTrainingEvaluation", trainingEvaluation);
        }
        catch (Exception ex)
        {
            var erroMsg = new Error();
            erroMsg.Message = ex.Message;
            return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
        }
    }

    public JsonResult CreateTrainingEvaluationRequest(string ApplicationCode)
    {
        try
        {
            var employee = Session["EmployeeData"] as EmployeeView;
            //var loggedInUser = employee?.UserID;
            var staffNo = Session["Username"].ToString();

            if (string.IsNullOrEmpty(staffNo))
            {
                return Json(new { message = "User session expired. Please login again.", success = false },
                    JsonRequestBehavior.AllowGet);
            }

            var docNo = Credentials.ObjNav.FnCreateTrainingFeedback(staffNo, ApplicationCode);

            return Json(new { message = docNo, success = true }, JsonRequestBehavior.AllowGet);
        }
        catch (Exception ex)
        {
            return Json(new { message = ex.Message.Replace("'", ""), success = false },
                JsonRequestBehavior.AllowGet);
        }
    }
    public JsonResult SubmitTrainingEvaluationLine(TrainingEvaluationLine trainingEvaluationLine)
    {
        try
        {
            var employee = Session["EmployeeData"] as EmployeeView;
            
            Credentials.ObjNav.InsertSelfAssessmentLine(
                trainingEvaluationLine.Training_Evaluation_No, trainingEvaluationLine.Training_Category, trainingEvaluationLine.Comments
            );

            return Json(new{ message = "Training evaluation submitted successfully", success = true });
        }
        catch (Exception ex)
        {
            return Json(new { message = ex.Message.Replace("'", ""), success = false },
                JsonRequestBehavior.AllowGet);
        }
    }

    public JsonResult DeleteTrainingLine(string code,string lineNo)
    {
        try
        {
             Credentials.ObjNav.deleteTrainingNeedsLine(code,Convert.ToInt32(lineNo));

            return Json(new { message = "Training line deleted successfully", success = true });
        }
        catch (Exception ex)
        {
            return Json(new { message = ex.Message.Replace("'", ""), success = false },
                JsonRequestBehavior.AllowGet);
        }
    }
    public JsonResult SubmitTrainingCost(TrainingCost trainingCost)
    {
        try
        {
            Credentials.ObjNav.FnInsertTrainingCost(
               trainingCost.Training_ID,
               trainingCost.Course_ID,
               Convert.ToInt32(trainingCost.Cost_Category),
               trainingCost.Cost_Item,
               trainingCost.Unit_Cost_LCY,
               trainingCost.Quantity
           );

            return Json(new { message = "Training Cost Submitted Successfully!", success = true }, JsonRequestBehavior.AllowGet);


        }
        catch (Exception ex)
        {
            return Json(new { message = ex.Message.Replace("'", ""), success = false },
                JsonRequestBehavior.AllowGet);
        }
    }
    public JsonResult DeleteTrainingCost(string docNo, string courseID, int entryNo)
    {
        try
        {
            Credentials.ObjNav.DeleteTrainingCost(docNo, courseID, entryNo);

            return Json(new { message = "Training cost deleted successfully", success = true },
                JsonRequestBehavior.AllowGet);
        }
        catch (Exception ex)
        {
            return Json(new { message = ex.Message.Replace("'", ""), success = false },
                JsonRequestBehavior.AllowGet);
        }
    }
    /// <summary>
    /// Training Requests
    /// </summary>
    public ActionResult TrainingRequisition()
    {
        try
        {
            if (Session["Username"] == null)
                return RedirectToAction("Login", "Login");
            return View();
        }
        catch (Exception ex)
        {
            var erroMsg = new Error();
            erroMsg.Message = ex.Message;
            return View("~/Views/Common/ErrorMessange.cshtml", erroMsg);
        }
    }
    public PartialViewResult TrainingRequisitionList()
    {
        var employee = Session["EmployeeData"] as EmployeeView;
        var userId = employee?.UserID;
        var staffNo = Session["Username"];
        var rsrceReq = $"TrainingRequisition?$filter=Employee_No eq '{staffNo}'&$format=json";
        var httpResponse = Credentials.GetOdataData(rsrceReq);

        using var streamReader = new StreamReader(httpResponse.GetResponseStream());
        var result = streamReader.ReadToEnd();

        var odataResponse = JsonConvert.DeserializeObject<ODataResponse<TrainingNeedRequests>>(result);
        var trainingNeedRequests = odataResponse?.Value ?? [];

        return PartialView("Partial Views/TrainingRequisitionList", trainingNeedRequests);
    }
    public ActionResult TrainingRequisitionDocumentView(string code)
    {
        var rsrceReq = $"TrainingRequisition?$filter=Code eq '{code}'&$format=json";
        var httpResponse = Credentials.GetOdataData(rsrceReq);
        using var streamReader = new StreamReader(httpResponse.GetResponseStream());
        var result = streamReader.ReadToEnd();
        var odataResponse = JsonConvert.DeserializeObject<ODataResponse<TrainingRequisition>>(result);
        var trainingNeedRequest = odataResponse?.Value?.FirstOrDefault();
        return View(trainingNeedRequest);
    }
    public ActionResult NewTrainingRequisition()
    {
        try
        {
            if (Session["Username"] == null)
            {
                return RedirectToAction("Login", "Login");
            }

            var employee = Session["EmployeeData"] as EmployeeView;
            var StaffNo = Session["Username"].ToString();
            var trainingRequisition = new TrainingRequisitionViewModel();

            var coursesList = new List<DropdownList>();
            var trainingPlanCode = Credentials.ObjNav.GetTrainingPlanCode();
            var pageCourses = $"TrainingPlanLines?$filter=Training_Plan_Code eq '{trainingPlanCode}' and Employee_No eq '{StaffNo}' and Status eq 'Approved'&format=json";
            var httpResponseCourses = Credentials.GetOdataData(pageCourses);
            using (var streamReader = new StreamReader(httpResponseCourses.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                var details = JObject.Parse(result);
                foreach (var jToken in details["value"])
                {
                    var config = (JObject)jToken;
                    var dropdownList = new DropdownList
                    {
                        Text = $"{(string)config["Course_Title"]} - {(string)config["Course_Description"]}",
                        Value = (string)config["Course_Title"]
                    };
                    coursesList.Add(dropdownList);
                }
            }

            trainingRequisition.ListOfCourses = coursesList.Select(x =>
                new SelectListItem
                {
                    Text = x.Text,
                    Value = x.Value
                }).ToList();

            return PartialView("Partial Views/NewTrainingRequisition", trainingRequisition);
        }
        catch (Exception ex)
        {
            var erroMsg = new Error();
            erroMsg.Message = ex.Message;
            return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
        }
    }

    ///Training Evaluuation
    public ActionResult TrainingEvaluationRequisitionList()
    {
        if (Session["Username"] == null)
            return RedirectToAction("Login", "Login");
        return View();
    }

    public PartialViewResult TrainingEvaluationRequisitionListPartialView()
    {
        var StaffNo = Session["Username"].ToString();
        var UserID = Session["UserID"].ToString();
        var trainingApplications = new List<TrainingApplications>();

        var page = "HRTrainingApplication?$filter=Created_By eq '" + UserID + "'&$format=json";

        var httpResponse = Credentials.GetOdataData(page);
        using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
        {
            var result = streamReader.ReadToEnd();

            var details = JObject.Parse(result);
            foreach (JObject config in details["value"])
            {
                var training = new TrainingApplications();
                training.Code = (string)config["Code"];
                training.CourseTitle = (string)config["Course_Title"];
                training.StartDateTime = (string)config["Start_DateTime"];
                training.EndDateTime = (string)config["End_DateTime"];
                training.Status = (string)config["Status"];
                training.Duration = (int)config["Duration"];
                training.Cost = (decimal)config["Cost"];
                training.Location = (string)config["Location"];
                training.Description = (string)config["Description"];
                training.Year = (string)config["Year"];
                training.Provider = (string)config["Provider"];
                training.EmployeeNo = (string)config["Employee_No"];
                training.ApplicationDate = (string)config["Application_Date"];
                training.NoSeries = (string)config["No_Series"];
                training.EmployeeDepartment = (string)config["Employee_Department"];
                training.EmployeeName = (string)config["Employee_Name"];
                training.ProviderName = (string)config["Provider_Name"];
                training.NoOfParticipants = (int)config["No_of_Participants"];
                training.ApprovedCost = (decimal)config["Approved_Cost"];
                training.GlobalDimension1Code = (string)config["Global_Dimension_1_Code"];
                training.GlobalDimension2Code = (string)config["Global_Dimension_2_Code"];
                training.ActualStartDate = (string)config["Actual_Start_Date"];
                training.ActualEndDate = (string)config["Actual_End_Date"];
                training.EstimatedCost = (decimal)config["Estimated_Cost"];
                training.ImprestCreated = (bool)config["Imprest_Created"];
                training.TrainingPlanCost = (decimal)config["Training_Plan_Cost"];
                training.Budget = (decimal)config["Budget"];
                training.Actual = (decimal)config["Actual"];
                training.Commitment = (decimal)config["Commitment"];
                training.GLAccount = (string)config["GL_Account"];
                training.BudgetName = (string)config["Budget_Name"];
                training.AvailableFunds = (decimal)config["Available_Funds"];
                training.Local = (string)config["Local"];
                training.RequiresFlight = (bool)config["Requires_Flight"];
                training.SupervisorNo = (string)config["Supervisor_No"];
                training.SupervisorName = (string)config["Supervisor_Name"];
                training.TrainingPlanNo = (string)config["Training_Plan_No"];
                training.TrainingVenueRegionCode = (string)config["Training_Venue_Region_Code"];
                trainingApplications.Add(training);
            }
        }

        return PartialView("~/Views/Training/Partial Views/TraningEvaluationList.cshtml", trainingApplications);
    }

    public JsonResult GetCourseDetails(string courseId)
    {
        try
        {
            if (string.IsNullOrEmpty(courseId))
            {
                return Json(new { success = false, message = "Course ID is required" }, JsonRequestBehavior.AllowGet);
            }

            var pageCourse = $"TrainingCourses?$filter=Course_ID eq '{courseId}'&$format=json";
            var httpResponse = Credentials.GetOdataData(pageCourse);
            using var streamReader = new StreamReader(httpResponse.GetResponseStream());
            var result = streamReader.ReadToEnd();
            var details = JObject.Parse(result);
            var courseData = details["value"].FirstOrDefault();

            if (courseData == null)
            {
                return Json(new { success = false, message = "Course not found" }, JsonRequestBehavior.AllowGet);
            }

            var config = (JObject)courseData;
            var courseDetails = new
            {
                CourseId = (string)config["Course_ID"],
                Description = (string)config["Course_Description"],
                DomainId = (string)config["Domain_Code"],
                DomainName = (string)config["Domain_Name"],
                ProviderId = (string)config["Provider_Code"],
                ProviderName = (string)config["Provider_Name"],
                Duration = (int?)config["Duration"] ?? 1,
                DurationType = (string)config["Duration_Type"] ?? "Days",
                TrainingType = (string)config["Training_Type"] ?? "External",
                EstimatedCost = (decimal?)config["Estimated_Cost"] ?? 0,
                StartDate = config["Start_Date"] != null ? DateTime.Parse((string)config["Start_Date"]).ToString("dd/MM/yyyy") : "",
                EndDate = config["End_Date"] != null ? DateTime.Parse((string)config["End_Date"]).ToString("dd/MM/yyyy") : "",
                Location = (string)config["Location"] ?? ""
            };

            return Json(new { success = true, course = courseDetails }, JsonRequestBehavior.AllowGet);
        }
        catch (Exception ex)
        {
            return Json(new { success = false, message = ex.Message.Replace("'", "") }, JsonRequestBehavior.AllowGet);
        }
    }
    public JsonResult SendTrainingRequestForApproval(string Code)
    {
        try
        {
            var employee = Session["EmployeeData"] as EmployeeView;

            if (string.IsNullOrEmpty(Code))
            {
                return Json(new { message = "Document Number is required", success = false },
                    JsonRequestBehavior.AllowGet);
            }

            var success = Credentials.ObjNav.sendTrainingRequestApproval(employee?.No, Code);

            return Json(new { message = "Training request sent for approval successfully", success = true },
                JsonRequestBehavior.AllowGet);

        }
        catch (Exception ex)
        {
            return Json(new { message = ex.Message.Replace("'", ""), success = false },
                JsonRequestBehavior.AllowGet);
        }
    }
    public JsonResult SubmitTrainingNeed(string docNo)
    {
        try
        {
            var employee = Session["EmployeeData"] as EmployeeView;

            Credentials.ObjNav.FnSubmitTrainingNeeds(docNo);

            return Json(new { message = "Training needs submitted sucessfully!", success = true },
                JsonRequestBehavior.AllowGet);

        }
        catch (Exception ex)
        {
            return Json(new { message = ex.Message.Replace("'", ""), success = false },
                JsonRequestBehavior.AllowGet);
        }
    }

    public JsonResult CancelTrainingRequestApproval(string docNo)
    {
        try
        {
            var employee = Session["EmployeeData"] as EmployeeView;
            if (string.IsNullOrEmpty(docNo))
            {
                return Json(new { message = "Document Number is required", success = false },
                    JsonRequestBehavior.AllowGet);
            }

            Credentials.ObjNav.cancelTrainingRequestApproval(employee?.No, docNo);

            return Json(new { message = "Training request approval cancelled successfully", success = true },
                JsonRequestBehavior.AllowGet);

        }
        catch (Exception ex)
        {
            return Json(new { message = ex.Message.Replace("'", ""), success = false },
                JsonRequestBehavior.AllowGet);
        }
    }

    public JsonResult SubmitTrainingEvaluation(string docNo)
    {
        try
        {
            var employee = Session["EmployeeData"] as EmployeeView;

            Credentials.ObjNav.SubmitTrainingEvaluation(docNo);

            return Json(new { message = "Training evaluation submitted sucessfully!", success = true },
                JsonRequestBehavior.AllowGet);

        }
        catch (Exception ex)
        {
            return Json(new { message = ex.Message.Replace("'", ""), success = false },
                JsonRequestBehavior.AllowGet);
        }
    }

    public JsonResult CreateTrainingRequisition(TrainingRequisitionCreate requisition)
    {
        try
        {
            var employee = Session["EmployeeData"] as EmployeeView;
            var loggedInUser = employee?.UserID;

            if (string.IsNullOrEmpty(loggedInUser))
            {
                return Json(new { message = "User session expired. Please login again.", success = false },
                    JsonRequestBehavior.AllowGet);
            }

            if (string.IsNullOrEmpty(requisition.CourseID))
            {
                return Json(new { message = "Course ID is required", success = false },
                    JsonRequestBehavior.AllowGet);
            }

            var documentNumber =Credentials.ObjNav.FnCreateTrainingRequisition(
               employee.No,
               loggedInUser,
               requisition.CourseID
           );

            return Json(new { message = documentNumber, success = true }, JsonRequestBehavior.AllowGet);


        }
        catch (Exception ex)
        {
            return Json(new { message = ex.Message.Replace("'", ""), success = false },
                JsonRequestBehavior.AllowGet);
        }
    }

    private decimal getDSAUnitCost(TrainingCostViewModel trainingCostViewModel)
    {
        try
        {
            var staffNo = Session["Username"].ToString();
            decimal unitCost = Credentials.ObjNav.SetDSAUnitCost( staffNo,trainingCostViewModel.DocumentNo, trainingCostViewModel.CourseID);
            return unitCost;
        }
        catch (Exception ex)
        {
            throw new Exception("Error fetching DSA Unit Cost: " + ex.Message);
        }
    }

}