﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices.AccountManagement;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Latest_Staff_Portal.Models;
using Latest_Staff_Portal.ViewModel;
using Newtonsoft.Json.Linq;

namespace Latest_Staff_Portal.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Login()
        {
            Session.Remove("Username");
            Session.Remove("StaffDetails");
            Session.RemoveAll();
            FormsAuthentication.SignOut();

            // Get current month number (1–12)
            ViewBag.CurrentMonth = DateTime.Now.Month;

            var user = new Authedication();
            return View(user);
        }

        [HttpPost]
        public JsonResult LoginUser(Authedication userlogin)
        {
            var msg = "";
            var success = false;
            var UserName = userlogin.UserName.ToUpper();
            var passwrd = userlogin.Password;
            var userID = "";
            var staffNo = "";
            var Redirect = "";
            try
            {
                using var pc = new PrincipalContext(ContextType.Domain, ConfigurationManager.AppSettings["AD_Server"]);
                var isValid = pc.ValidateCredentials(UserName, passwrd) ||
                ConfigurationManager.AppSettings["IS_PROD"] == "NON-PROD";
                if (isValid)
                {
                    if (UserName.Contains("\\"))
                        userID = UserName;
                    else
                        userID = ConfigurationManager.AppSettings["DOMAIN"] + @"\" + UserName;
                    Session["LoginId"] = userID;
                    Session["LoginUseName"] = UserName;
                    if (ConfigurationManager.AppSettings["IS_PROD"] == "NON-PROD" || ConfigurationManager.AppSettings["IS_PROD"] == "PROD")
                    //if (ConfigurationManager.AppSettings["IS_PROD"] == "PROD")
                    {
                        Redirect = "/Dashboard/Dashboard";
                        msg = Redirect;
                        try
                        {
                            Redirect = "/Dashboard/Dashboard";
                            var page = "UserSetup?$filter=User_ID eq '" + userID + "'&format=json";

                            var httpResponse = Credentials.GetOdataData(page);
                            using var streamReader = new StreamReader(httpResponse.GetResponseStream());
                            var result = streamReader.ReadToEnd();

                            var details = JObject.Parse(result);

                            if (details["value"].Any())
                            {
                                foreach (var jToken in details["value"])
                                {
                                    var config = (JObject)jToken;
                                    if ((string)config["Employee_No"] != "")
                                    {
                                        userID = (string)config["User_ID"];
                                        staffNo = (string)config["Employee_No"];

                                        var Role = "";
                                        Session["Username"] = (string)config["Employee_No"];
                                        Session["UserID"] = (string)config["User_ID"];
                                        Session["IsStoreManager"] = (bool)config["Is_Store_Manager"];
                                        var IDno = (string)config["IDNumber"];
                                        var Email = (string)config["Email"];
                                        var PhoneNo = (string)config["PhoneNo"];
                                        EmployeeData(staffNo);
                                        Role = "ALLUSERS";
                                        SetUserAuthedication(UserName, Email, Role);
                                        msg = Redirect;
                                        success = true;
                                    }
                                    else
                                    {
                                        msg =
                                            "No Employee Number assigned to the applied username. Contact HR / ICT";
                                        success = false;
                                    }
                                }
                            }
                            else
                            {
                                msg = "No Employee Number assigned to the applied username. Contact HR / ICT";
                                success = false;
                            }
                        }
                        catch (Exception ex)
                        {
                            msg = ex.Message;
                            success = false;
                        }
                    }


                    //request for OTP
                    else
                    {
                        Redirect = "/Settings/RequestOtp";
                        msg = Redirect;
                        success = true;
                        var page = "UserSetup?$filter=User_ID eq '" + userID + "'&format=json";

                        var httpResponse = Credentials.GetOdataData(page);
                        using var streamReader = new StreamReader(httpResponse.GetResponseStream());
                        var result = streamReader.ReadToEnd();

                        var details = JObject.Parse(result);

                        if (details["value"].Any())
                        {
                            foreach (var jToken in details["value"])
                            {
                                var config = (JObject)jToken;
                                if ((string)config["Employee_No"] != "")
                                {
                                    if (ConfigurationManager.AppSettings["IS_PROD"] == "NON-PROD")
                                    {
                                        Session["Username"] = (string)config["Employee_No"];
                                        Session["UserID"] = (string)config["User_ID"];
                                        Session["IsStoreManager"] = (bool)config["Is_Store_Manager"];
                                    }

                                    userID = (string)config["User_ID"];
                                    staffNo = (string)config["Employee_No"];
                                    var Role = "";
                                    var IDno = (string)config["IDNumber"];
                                    var Email = "";
                                    var PhoneNo = "";

                                    var pageEmp = "EmployeeList?$filter=No eq '" + staffNo + "'&$format=json";

                                    var httpResponseEmp = Credentials.GetOdataData(pageEmp);
                                    using (var streamReaderEmp =
                                           new StreamReader(httpResponseEmp.GetResponseStream()))
                                    {
                                        var resultEmp = streamReaderEmp.ReadToEnd();

                                        var det = JObject.Parse(resultEmp);

                                        foreach (var data in det["value"])
                                        {
                                            Email = (string)data["E_Mail"];
                                            PhoneNo = (string)data["Phone_No"];
                                        }
                                    }

                                    Session["Phone"] = PhoneNo;
                                    Session["Email"] = Email;
                                    Session["EmpNo"] = staffNo;
                                    msg = Redirect;
                                    success = true;
                                }
                                else
                                {
                                    msg =
                                        "No Employee Number assigned to the applied username. Contact HR / ICT";
                                    success = false;
                                }
                            }
                        }
                        else
                        {
                            msg = "No Employee Number assigned to the applied username. Contact HR / ICT";
                            success = false;
                        }
                    }

                }
                else
                {
                    msg = "Invalid username or password!";
                }
            }
            catch (Exception ex)
            {
                msg = ex.Message;
                success = false;
            }

            return Json(new { message = msg, success }, JsonRequestBehavior.AllowGet);
        }


        public JsonResult ConfirmOtp(string otp)
        {
            try
            {
                var msg = "";
                var success = false;
                var staffNo = "";
                var Redirect = "";
                var upperOtp = otp.ToUpper();
                var userID = "";
                //var UserName = userId.ToUpper();
                //if (UserName.Contains("\\"))
                //    userID = UserName;
                //else
                //    userID = ConfigurationManager.AppSettings["DOMAIN"] + @"\" + UserName;

                var UserID = Session["LoginId"].ToString();
                //bool confirmOtp = true;
                //bool confirmOtp = Credentials.ObjNav.ReturnPortalOTPCode(empNo, upperOtp);
                bool confirmOtp = Credentials.ObjNav.ValidateOTP(upperOtp, UserID);
                if (confirmOtp)
                {
                    try
                    {
                        //var userID = Session["LoginId"].ToString();
                        var UserName = Session["LoginUseName"].ToString();
                        Redirect = "/Dashboard/Dashboard";

                        var page = $"UserSetup?$filter=User_ID eq '{UserID}'&format=json";
                       

                        var httpResponse = Credentials.GetOdataData(page);
                        using var streamReader = new StreamReader(httpResponse.GetResponseStream());
                        var result = streamReader.ReadToEnd();

                        var details = JObject.Parse(result);

                        if (details["value"].Any())
                        {
                            foreach (var jToken in details["value"])
                            {
                                var config = (JObject)jToken;
                                if ((string)config["Employee_No"] != "")
                                {
                                    userID = (string)config["User_ID"];
                                    staffNo = (string)config["Employee_No"];

                                    var Role = "";
                                    Session["Username"] = (string)config["Employee_No"];
                                    Session["UserID"] = (string)config["User_ID"];
                                    Session["IsStoreManager"] = (bool)config["Is_Store_Manager"];
                                    var IDno = (string)config["IDNumber"];
                                    var Email = (string)config["EMail"];
                                    var PhoneNo = (string)config["CellPhoneNumber"];

                                    ESSRoleSetup(userID, UserName, Email);
                                    EmployeeData(staffNo);
                                    if (Credentials.ObjNav.CheckPasswordChanged((string)config["Employee_No"]))
                                        Redirect = "/Settings/ChangePassword";


                                    msg = Redirect;
                                    success = true;
                                }
                                else
                                {
                                    msg = "No Employee Number assigned to the applied username. Contact HR / ICT";
                                    success = false;
                                }
                            }
                        }
                        else
                        {
                            msg = "No Employee Number assigned to the applied username. Contact HR / ICT";
                            success = false;
                        }
                    }
                    catch (Exception ex)
                    {
                        msg = ex.Message;
                        success = false;
                    }

                    return Json(new { message = msg, success = true }, JsonRequestBehavior.AllowGet);
                }

                msg = "Incorrect OTP. Please try again!!!";
                return Json(new { message = msg, success = false }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

        private EmployeeView EmployeeData(string staffNo)
        {
            try
            {
                var empView = new EmployeeView();
                var totAssets = 0;
                var userRole = "";
                var page = "EmployeeList?$filter=No eq '" + staffNo + "'&$format=json";
                bool isSupervisor = false;

                var httpResponse = Credentials.GetOdataData(page);
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();

                    var details = JObject.Parse(result);
                    foreach (var jToken in details["value"])
                    {
                        var config = (JObject)jToken;

                        empView.No = (string)config["No"];
                        empView.Title = (string)config["Title"];
                        empView.FirstName = (string)config["First_Name"];
                        empView.MiddleName = (string)config["Middle_Name"];
                        empView.LastName = (string)config["Last_Name"];
                        empView.FullName = (string)config["First_Name"] + " " + (string)config["Middle_Name"] + " " + (string)config["Last_Name"];
                        empView.Mobile_Phone_No = (string)config["First_Name"];
                        empView.Email= (string)config["E_Mail"];
                        empView.CompanyEmail= (string)config["Company_E_Mail"];
                        empView.DateOfBirth= (DateTime)config["Date_Of_Birth"];
                        empView.NHIFNo= (string)config["N_H_I_F_No"];
                        empView.SocialSecurityNo= (string)config["Social_Security_No"];
                        empView.IDNumber= (string)config["ID_Number"];
                        empView.UserID= (string)config["User_ID"];
                        empView.CurrentPositionID = (string)config["Current_Position_ID"];
                        empView.JobTitle2 = (string)config["Job_Title2"];
                        empView.SearchName = (string)config["Search_Name"];
                        empView.CountyofOrigin = (string)config["County_of_Origin"];
                        empView.CountyofOriginName = (string)config["County_of_Origin_Name"];
                        empView.Gender = (string)config["Gender"];
                        empView.MaritalStatus = (string)config["Marital_Status"];
                        empView.Religion = (string)config["Religion"];
                        empView.Disabled = (bool)config["Disabled"];
                        empView.DisabilityNo = (string)config["Disability_No"];
                        empView.DisabilityCertExpiry = (DateTime)config["Disability_Cert_Expiry"];
                        empView.EthnicOrigin = (string)config["Ethnic_Origin"];
                        empView.LastDateModified = (DateTime)config["Last_Date_Modified"];
                        empView.SalaryScale = (string)config["Salary_Scale"];
                        empView.Present = (string)config["Present"];
                        empView.EmployeePostingGroup1 = (string)config["Employee_Posting_Group1"];
                        empView.IncrementDate = (DateTime)config["Increment_Date"];
                        empView.IncrementalMonth = (string)config["Incremental_Month"];
                        empView.LastIncrementDate = (DateTime)config["Last_Increment_Date"];
                        empView.GlobalDimension1Code = (string)config["Global_Dimension_1_Code"];
                        empView.DepartmentName = (string)config["Department_Name"];
                        empView.GlobalDimension2Code = (string)config["Global_Dimension_2_Code"];
                        empView.DirectorateCode = (string)config["Directorate_Code"];
                        empView.ImplementingUnitName = (string)config["Implementing_Unit_Name"];
                        empView.DepartmentCode = (string)config["Department_Code"];
                        empView.DutyStation = (string)config["Duty_Station"];
                        empView.OrganisationUnitName = (string)config["Organisation_Unit_Name"];
                        empView.EmployeeJobType = (string)config["Employee_Job_Type"];
                        empView.ResponsibilityCenter = (string)config["Responsibility_Center"];
                        empView.Address = (string)config["Address"];
                        empView.Address2 = (string)config["Address_2"];
                        empView.PostCode = (string)config["Post_Code"];
                        empView.AdministrativeUnit = (string)config["Global_Dimension_2_Code"];
                        //empView.IsStoreManager = (bool)config["Is_Supply_Chain_Officer"];
                    }
                }
                empView.AllocatedAssets = totAssets;
                empView.UserRole = userRole;
                Session["EmployeeData"] = empView;
                return empView;
            }
            catch (Exception ex)
            {
                var erroMsg = new Error();
                erroMsg.Message = ex.Message;
                throw;
            }
        }

        private void SetUserAuthedication(string UserName, string email, string role)
        {
            try
            {
                var userModel = new UserViewModel();
                userModel.UserName = UserName;
                userModel.Email = email;
                userModel.RoleName = role;
                var userData = string.Format("{0}|{1}|{2}|{3}", userModel.UserName, userModel.UserID, userModel.Email,
                    userModel.RoleName);
                var ticket = new FormsAuthenticationTicket(1, userModel.UserName, DateTime.Now,
                    DateTime.Now.AddMinutes(1), false, userData);
                var encTicket = FormsAuthentication.Encrypt(ticket);

                var cookie = new HttpCookie(FormsAuthentication.FormsCookieName, encTicket);
                Response.Cookies.Add(cookie);
            }
            catch (Exception ex)
            {
                ex.Data.Clear();
            }
        }

        [HttpGet]
        public ActionResult ForgotPassword()
        {
            var user = new Authedication();
            return View(user);
        }

        [HttpPost]
        public ActionResult ForgotPassword(Authedication userlogin)
        {
            var msg = "";
            var email = string.Empty;
            var success = false;
            var UserName = userlogin.UserName.ToUpper();
            try
            {
                var userID = "";
                if (UserName.Contains("\\"))
                    userID = UserName;
                else
                    userID = ConfigurationManager.AppSettings["DOMAIN"] + @"\" + UserName;

                var page = "EmployeeList?$filter=User_ID eq '" + userID + "'&$format=json";

                var httpResponse = Credentials.GetOdataData(page);
                using var streamReader = new StreamReader(httpResponse.GetResponseStream());
                var result = streamReader.ReadToEnd();

                var details = JObject.Parse(result);

                if (details["value"].Any())
                {
                    foreach (var jToken in details["value"])
                    {
                        var config = (JObject)jToken;
                        var User = (string)config["User_ID"];
                        email = (string)config["Company_E_Mail"];
                        if (User != "")
                        {
                            if (email != "")
                            {
                                #region generate random password

                                var rand = new Random();
                                var randAlpha = new Random();
                                var newpassint = rand.Next(10000, 99999);

                                var alphabetPosition = randAlpha.Next(1, 26);
                                var isCap = alphabetPosition % 2 == 0 ? true : false;
                                var theAlphabet = GetTheAlphabet(alphabetPosition, isCap);

                                alphabetPosition = randAlpha.Next(1, 26);
                                isCap = alphabetPosition % 2 == 0 ? true : false;
                                theAlphabet += GetTheAlphabet(alphabetPosition, isCap);

                                alphabetPosition = randAlpha.Next(1, 26);
                                isCap = alphabetPosition % 2 == 0 ? true : false;
                                theAlphabet += GetTheAlphabet(alphabetPosition, isCap);

                                alphabetPosition = randAlpha.Next(1, 26);
                                isCap = alphabetPosition % 2 == 0 ? true : false;
                                theAlphabet += GetTheAlphabet(alphabetPosition, isCap);

                                //string newpass = theAlphabet + "#" + newpassint.ToString() + "?" + alphabetPosition.ToString() + "@";
                                var newpass = theAlphabet + "#" + newpassint + "@" + alphabetPosition;

                                #endregion generate random password

                                var ok = Credentials.ResetPassword(User, newpass);
                                if (ok == "CHANGED")
                                {
                                    const string subject = "STAFF PORTAL CREDENTIALS";
                                    var emailmsg =
                                        "Staff portal credentials reset:<br />New password is <b />" + newpass +
                                        "" +
                                        "<br />Remember to change your password after you login";
                                    if (CommonClass.SendEmailAlert(emailmsg, email, subject))
                                    {
                                        msg = "A New password has been send to your Email<b>(" + email +
                                              ")</b>. Use it to login. Remember to change your password after you login";
                                        success = true;
                                    }
                                    else
                                    {
                                        msg =
                                            "An error occured while sending you the credentials.Please contact the ICT office administrator.";
                                        success = false;
                                    }
                                }
                                else
                                {
                                    msg = "Failed to reset password";
                                    success = false;
                                }
                            }
                            else
                            {
                                msg = "Warning!, password reset failed!. E-Mail empty. Contact your administrator!";
                                success = false;
                            }
                        }
                        else
                        {
                            msg = "User Name not found. Confirm if the user name is correct";
                            success = false;
                        }
                    }
                }
                else
                {
                    msg = "User Name not found. Confirm if the user name is correct";
                    success = false;
                }
            }
            catch (Exception ex)
            {
                msg = ex.Message.Replace("'", "");
                success = false;
            }

            return Json(new { message = msg, success }, JsonRequestBehavior.AllowGet);
        }

        private string GetTheAlphabet(int alphabetPosition, bool isCap)
        {
            var rval = string.Empty;
            switch (alphabetPosition)
            {
                case 1:
                    rval = "A";
                    break;
                case 2:
                    rval = "B";
                    break;
                case 3:
                    rval = "C";
                    break;
                case 4:
                    rval = "D";
                    break;
                case 5:
                    rval = "E";
                    break;
                case 6:
                    rval = "F";
                    break;
                case 7:
                    rval = "G";
                    break;
                case 8:
                    rval = "H";
                    break;
                case 9:
                    rval = "I";
                    break;
                case 10:
                    rval = "J";
                    break;
                case 11:
                    rval = "K";
                    break;
                case 12:
                    rval = "L";
                    break;
                case 13:
                    rval = "M";
                    break;
                case 14:
                    rval = "N";
                    break;
                case 15:
                    rval = "O";
                    break;
                case 16:
                    rval = "P";
                    break;
                case 17:
                    rval = "Q";
                    break;
                case 18:
                    rval = "R";
                    break;
                case 19:
                    rval = "S";
                    break;
                case 20:
                    rval = "T";
                    break;
                case 21:
                    rval = "U";
                    break;
                case 22:
                    rval = "V";
                    break;
                case 23:
                    rval = "W";
                    break;
                case 24:
                    rval = "X";
                    break;
                case 25:
                    rval = "Y";
                    break;
                default:
                    rval = "Z";
                    break;
            }

            return isCap ? rval : rval.ToLower();
        }


        public ESSRoleSetup ESSRoleSetup(string empNo, string UserName, string Email)
        {
            var roleSetupValue = new ESSRoleSetup();
            var Role = "";

            var rolePage = "ESSRoleSetup?$filter=User_ID eq '" + empNo + "'&$format=json";

            var httpResponseSettings = Credentials.GetOdataData(rolePage);
            using (var streamReader = new StreamReader(httpResponseSettings.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();

                var details = JObject.Parse(result);

                foreach (var jToken in details["value"])
                {
                    var config = (JObject)jToken;
                    roleSetupValue.User_ID = (string)config["User_ID"];
                    roleSetupValue.UserName = (string)config["UserName"];
                    roleSetupValue.Employee_Name = (string)config["Employee_Name"];
                    roleSetupValue.Employee_No = (string)config["Employee_No"];
                    roleSetupValue.Accounts_User = (bool)config["Accounts_User"];
                    roleSetupValue.Accounts_Approver = (bool)config["Accounts_Approver"];
                    roleSetupValue.Audit_Officer = (bool)config["Audit_Officer"];
                    roleSetupValue.HQ_Accountant = (bool)config["HQ_Accountant"];
                    roleSetupValue.HQ_Finance_Officer = (bool)config["HQ_Finance_Officer"];
                    roleSetupValue.HQ_Procurement_Officer = (bool)config["HQ_Procurement_Officer"];
                    roleSetupValue.Station_Accountant = (bool)config["Station_Accountant"];
                    roleSetupValue.Station_Procurement_Office = (bool)config["Station_Procurement_Office"];
                    roleSetupValue.DAAS_Officer = (bool)config["DAAS_Officer"];
                    roleSetupValue.HR_Welfare_Officer = (bool)config["HR_Welfare_Officer"];
                    roleSetupValue.Mobility_Officer = (bool)config["Mobility_Officer"];
                    roleSetupValue.Procurement_officer = (bool)config["Procurement_officer"];
                    roleSetupValue.Recruitment_Officer = (bool)config["Recruitment_Officer"];
                    roleSetupValue.Revenue_Officer = (bool)config["Revenue_Officer"];
                    roleSetupValue.Transport_Officer = (bool)config["Transport_Officer"];
                }
            }

            if (roleSetupValue.HQ_Accountant || roleSetupValue.Station_Accountant)
            {
                Role = "ACCOUNTANTS";
            }
            else if (roleSetupValue.HQ_Procurement_Officer || roleSetupValue.Station_Procurement_Office)
            {
                Role = "PROCUREMENT";
            }
            else
            {
                Role = "ALLUSERS";
            }
            SetUserAuthedication(UserName, Email, Role);
            Session["ESSRoleSetup"] = roleSetupValue;

            return roleSetupValue;
        }


    }
}