﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Latest_Staff_Portal.Models;
using Latest_Staff_Portal.ViewModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Latest_Staff_Portal.Controllers
{
    public class PettyCashController : Controller
    {
        public ActionResult PettyCash()
        {
            try
            {
                if (Session["Username"] == null)
                    return RedirectToAction("Login", "Login");
                return View();
            }
            catch (Exception ex)
            {
                var erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return View("~/Views/Common/ErrorMessange.cshtml", erroMsg);
            }
        }
        public PartialViewResult PettyCashList()
        {
            var employee = Session["EmployeeData"] as EmployeeView;
            var userId = employee?.UserID;
            var StaffNo = Session["Username"].ToString();
            var rsrceReq = $"PettyCashVoucher?$filter= Created_By eq '{userId}' and Payment_Type eq 'Petty Cash'&$format=json";
            var httpResponse = Credentials.GetOdataData(rsrceReq);

            using var streamReader = new StreamReader(httpResponse.GetResponseStream());
            var result = streamReader.ReadToEnd();

            var odataResponse = JsonConvert.DeserializeObject<ODataResponse<PettyCash>>(result);
            var pettyCash = odataResponse?.Value ?? [];

            return PartialView("PartialViews/PettyCashList", pettyCash);
        }

        public ActionResult PettyCashDocumentView(string code)
        {
            var rsrceReq = $"PettyCashVoucher?$filter=No eq '{code}'&$format=json";
            var httpResponse = Credentials.GetOdataData(rsrceReq);
            using var streamReader = new StreamReader(httpResponse.GetResponseStream());
            var result = streamReader.ReadToEnd();
            var odataResponse = JsonConvert.DeserializeObject<ODataResponse<PettyCash>>(result);
            var pettyCashRequest = odataResponse?.Value?.FirstOrDefault();
            return View("PettyCashDocumentView", pettyCashRequest);
        }

        public JsonResult SubmitPettyCashApprovalRequest(string docNo)
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;
                var UserID = employee?.UserID;

                Credentials.ObjNav.SendPettyCashForApproval(docNo, UserID);
                Credentials.ObjNav.UpdateApprovalEntrySenderID(57000, docNo, UserID);

                return Json(new { message = "Document submitted for approval sucessfully!", success = true },
                    JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult CancelDocApprovalRequest(string docNo)
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;
                var UserID = employee?.UserID;
                if (string.IsNullOrEmpty(docNo))
                {
                    return Json(new { message = "Document Number is required", success = false },
                        JsonRequestBehavior.AllowGet);
                }

                Credentials.ObjNav.FnCancelPaymentDocuments(docNo, UserID); 

                return Json(new { message = "Approval Request cancelled successfully", success = true },
                    JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

        public PartialViewResult PvLines(string PvHeaderNo, string status)
        {
            ViewBag.Status = status;
            var rsrceReq = $"PVCLines?$filter= No eq '{PvHeaderNo}' &$format=json";
            var httpResponse = Credentials.GetOdataData(rsrceReq);

            using var streamReader = new StreamReader(httpResponse.GetResponseStream());
            var result = streamReader.ReadToEnd();

            var odataResponse = JsonConvert.DeserializeObject<ODataResponse<PvLines>>(result);
            var pvlines = odataResponse?.Value ?? [];

            return PartialView("PartialViews/PvLines", pvlines);
        }

        public ActionResult GeneratePVReport(string docNo)
        {
            try
            {
                var staffNo = Session["Username"].ToString();
                var _filename = staffNo.Replace("/", "");
                var message = "";
                bool success = false, view = false;

                var employeeView = Session["EmployeeData"] as EmployeeView;
                var dimension = employeeView?.GlobalDimension1Code;

                message = Credentials.ObjNav.GenerateVoucherReport(docNo);
                if (string.IsNullOrEmpty(message))
                {
                    success = false;
                    message = "File Not Found";
                }
                else
                {
                    success = true;
                }

                return Json(new { message, success, view }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message, success = false }, JsonRequestBehavior.AllowGet);
            }
        }
        public PartialViewResult NewPettyCash()
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;
                var StaffNo = Session["Username"].ToString();
                var pettyCash = new PettyCashViewModel();
                pettyCash.UserId = employee.UserID;


                return PartialView("PartialViews/NewPettyCash", pettyCash);
            }
            catch (Exception ex)
            {
                var erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
            }
        }

        public JsonResult CreatePettyCash(PettyCashViewModel pettyCashViewModel)
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;
                //var loggedInUser = employee?.UserID;
                var staffNo = Session["Username"].ToString();
                var UserID = employee.UserID;

                if (string.IsNullOrEmpty(staffNo))
                {
                    return Json(new { message = "User session expired. Please login again.", success = false },
                        JsonRequestBehavior.AllowGet);
                }

                var docNo = Credentials.ObjNav.FnCreatePettyCashVoucherTest1(UserID, pettyCashViewModel.PaymentNarration);

                RedirectToAction("PettyCashDocumentView", new { code = docNo });
                return Json(new { message = docNo, success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult NewPvLine(string docNo)
        {
            try
            {
                if (Session["Username"] == null)
                {
                    return RedirectToAction("Login", "Login");
                }

                var employee = Session["EmployeeData"] as EmployeeView;
                var pvLine = new PvLinesViewModel();
                Session["httpResponse"] = null;

                pvLine.No = docNo;


                // Get gl account List
                var glAccountList = new List<DropdownList>();
                var pageGlAccounts = "GLAccounts?$filter=Available_for_workplaning eq true&$format=json";
                var httpResponseDomains = Credentials.GetOdataData(pageGlAccounts);
                using (var streamReader = new StreamReader(httpResponseDomains.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var details = JObject.Parse(result);
                    glAccountList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["No"]} - {(string)config["Name"]}", Value = (string)config["No"] });
                }

                // Get funding source List
                var fundingSourceList = new List<DropdownList>();
                var pageFundingSource = "DimensionValueList?$filter=Dimension_Code eq 'FUNDING SOURCE'&$format=json";
                var httpResponseProviders = Credentials.GetOdataData(pageFundingSource);
                using (var streamReader = new StreamReader(httpResponseProviders.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var details = JObject.Parse(result);
                    fundingSourceList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["Code"]} - {(string)config["Name"]}", Value = (string)config["Code"] });
                }

                // Get Vote List  
                var voteList = new List<DropdownList>();
                var pageCourses = "DimensionValueList?$filter=Dimension_Code eq 'VOTE'&$format=json";
                var httpResponseCourses = Credentials.GetOdataData(pageCourses);
                using (var streamReader = new StreamReader(httpResponseCourses.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var details = JObject.Parse(result);
                    voteList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["Code"]} - {(string)config["Name"]}", Value = (string)config["Code"] });
                }

                pvLine.GlAccountList = glAccountList.Select(x =>
                    new SelectListItem
                    {
                        Text = x.Text,
                        Value = x.Value
                    }).ToList();

                pvLine.ListOfVoteItem = voteList.Select(x =>
                    new SelectListItem
                    {
                        Text = x.Text,
                        Value = x.Value
                    }).ToList();

                pvLine.ListOfFundingSource = fundingSourceList.Select(x =>
                    new SelectListItem
                    {
                        Text = x.Text,
                        Value = x.Value
                    }).ToList();

                return PartialView("PartialViews/NewPvLine", pvLine);
            }
            catch (Exception ex)
            {
                var erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
            }
        }

        public JsonResult SubmitPvLine(PvLinesViewModel pvLinesViewModel)
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;


                var success = Credentials.ObjNav.FnInsertModifyPVlines(pvLinesViewModel.No, pvLinesViewModel.AccountNo, pvLinesViewModel.FundingSource, pvLinesViewModel.VoteItem, pvLinesViewModel.Amount, 0);

                return Json(success ? new { message = "PV line submitted successfully", success = true } : new { message = "Failed to submit PV line", success = false }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult DeletePvLine(string code, string lineNo)
        {
            try
            {
                Credentials.ObjNav.FnDeletePVLines(Convert.ToInt32(lineNo), code);

                return Json(new { message = "PV line deleted successfully", success = true });
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

        //pettycash surrender
        public ActionResult PVSurrender()
        {
            try
            {
                if (Session["Username"] == null)
                    return RedirectToAction("Login", "Login");
                return View();
            }
            catch (Exception ex)
            {
                var erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return View("~/Views/Common/ErrorMessange.cshtml", erroMsg);
            }
        }
        public PartialViewResult PvSurrenderList()
        {
            var employee = Session["EmployeeData"] as EmployeeView;
            var userId = employee?.UserID;
            var StaffNo = Session["Username"].ToString();
            var rsrceReq = $"PettyCashSurrender?$filter= Created_By eq '{userId}' and Payment_Type eq 'Petty Cash Surrender'&$format=json";
            //var rsrceReq = $"PettyCashSurrender?$filter=Document_Type eq 'Surrender'&$format=json";
            var httpResponse = Credentials.GetOdataData(rsrceReq);

            using var streamReader = new StreamReader(httpResponse.GetResponseStream());
            var result = streamReader.ReadToEnd();

            var odataResponse = JsonConvert.DeserializeObject<ODataResponse<PettyCashSurrender>>(result);
            var pettyCash = odataResponse?.Value ?? [];

            return PartialView("PartialViews/PvSurrenderList", pettyCash);
        }

        public PartialViewResult NewPvSurrender()
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;
                var StaffNo = Session["Username"].ToString();
                var pvSurrender = new PvSurrenderViewModel();
                var UserID = employee.UserID;


                // Get petty cash vouchers
                var pvlist = new List<DropdownList>();
                var pageApprovedPVs = $"ApprovedPettyCashVoucher?$filter=Created_By eq '{UserID}' and Posted eq true and Surrendered eq false and Status eq 'Released' and Account_No eq '{StaffNo}' &$format=json";
                var httpResponsePvs = Credentials.GetOdataData(pageApprovedPVs);
                using (var streamReader = new StreamReader(httpResponsePvs.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var details = JObject.Parse(result);
                    pvlist.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["No"]}", Value = (string)config["No"] });
                }

                // Get Pay modes
                var payModeList = new List<DropdownList>();
                var pagePayMode = "PayMode";
                var httpResponsePayModes = Credentials.GetOdataData(pagePayMode);
                using (var streamReader = new StreamReader(httpResponsePayModes.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var details = JObject.Parse(result);
                    payModeList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["Description"]}", Value = (string)config["Code"] });
                }

                pvSurrender.ListOfApprovedPV = pvlist.Select(x =>
                   new SelectListItem
                   {
                       Text = x.Text,
                       Value = x.Value
                   }).ToList();
                 pvSurrender.ListOfPayModes = payModeList.Select(x =>
                   new SelectListItem
                   {
                       Text = x.Text,
                       Value = x.Value
                   }).ToList();




                return PartialView("PartialViews/NewPvSurrender", pvSurrender);
            }
            catch (Exception ex)
            {
                var erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
            }
        }

        public ActionResult PVSurrenderDocumentView(string code)
        {
            var rsrceReq = $"PettyCashSurrender?$filter=No eq '{code}'&$format=json";
            var httpResponse = Credentials.GetOdataData(rsrceReq);
            using var streamReader = new StreamReader(httpResponse.GetResponseStream());
            var result = streamReader.ReadToEnd();
            var odataResponse = JsonConvert.DeserializeObject<ODataResponse<PettyCashSurrender>>(result);
            var pvSurrender = odataResponse?.Value?.FirstOrDefault();
            return View("PVSurrenderDocumentView", pvSurrender);
        }

        public PartialViewResult PvSurrenderLines(string PvHeaderNo, string status)
        {
            ViewBag.Status = status;
            ViewBag.DocNo = PvHeaderNo;
            var rsrceReq = $"PettyCashSurrenderLines?$filter= No eq '{PvHeaderNo}' &$format=json";
            var httpResponse = Credentials.GetOdataData(rsrceReq);

            using var streamReader = new StreamReader(httpResponse.GetResponseStream());
            var result = streamReader.ReadToEnd();

            var odataResponse = JsonConvert.DeserializeObject<ODataResponse<PvSurrenderLine>>(result);
            var pvSurrenderLines = odataResponse?.Value ?? [];

            return PartialView("PartialViews/PvSurrenderLines", pvSurrenderLines);
        }

        public JsonResult UpdatePVActualSpent(int lineNo, decimal actualSpent, string DocNo)
        {
            try
            {
                // Validate input
                if (actualSpent < 0)
                {
                    return Json(new { success = false, message = "Actual spent amount cannot be negative." });
                }


                Credentials.ObjNav.FnModifyPettyCashSurrenderLines(DocNo, actualSpent, lineNo);

                return Json(new { message = "PV Surrender submitted successfully", success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

                return Json(new { success = false, message = ex.Message });
            }
        }

        public JsonResult SubmitPVSurrender(PvSurrenderViewModel pvSurrenderViewModel)
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;
                var UserID = employee.UserID;


                var docNo = Credentials.ObjNav.FnCreatePettyCashSurrender(UserID, pvSurrenderViewModel.PettyCashNo, pvSurrenderViewModel.PayMode);

                RedirectToAction("PVSurrenderDocumentView", new { code = docNo });
                return Json(new { message = docNo, success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

    }
}