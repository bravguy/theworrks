﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using Latest_Staff_Portal.CustomSecurity;
using Latest_Staff_Portal.Models;
using Latest_Staff_Portal.ViewModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Latest_Staff_Portal.Controllers
{
    [CustomeAuthentication]
    public class DashboardController : Controller
    {
        // GET: Dashboard
        public ActionResult Dashboard()
        {
            if (Session["Username"] == null) return RedirectToAction("Login", "Login");

            try
            {
                var EmpView = Session["EmployeeData"] as EmployeeView;
                // Get leave balance
                ViewBag.LeaveBalance = GetLeaveBalanceData();

                //Get approvals count
                ViewBag.Approvals = GetApprovalsCount();

                // Get imprest count
                ViewBag.Imprests = GetImprestsCount();

                // Get assigned assets count
                ViewBag.AssignedAssets = GetAssignedAssetsCount();

                // Get total approvals
                ViewBag.TotalApprovals = GetTotalApprovals();
                // Get total imprests
                ViewBag.TotalImprests = GetTotalImprests();
                // Get total assigned assets
                ViewBag.TotalAssignedAssets = GetTotalAssignedAssets();


                // Set progress percentages
                ViewBag.LeaveBalanceProgress = CalculateLeaveBalanceProgress(ViewBag.LeaveBalance);
                ViewBag.ImprestProgress = CalculateImprestProgress(ViewBag.Imprests, ViewBag.TotalImprests);
                ViewBag.ApprovalProgress = CalculateApprovalProgress(ViewBag.Approvals, ViewBag.TotalApprovals);
                ViewBag.AssignedAssetsProgress = CalculateAssignedAssetsProgress(ViewBag.AssignedAssets, ViewBag.TotalAssignedAssets);



                return View();
            }
            catch (Exception ex)
            {
                var erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return View("~/Views/Common/ErrorMessange.cshtml", erroMsg);
            }
        }

        private decimal GetLeaveBalanceData()
        {
            try
            {
                var StaffNo = Session["Username"].ToString();
                decimal availableDays = 0;
                var leaveDays = CommonClass.GetLeaveBal(StaffNo, "ANNUAL");
                if (leaveDays[0] > 1)
                    availableDays = leaveDays[0];
                return availableDays;
            }
            catch (Exception)
            {
                // Return default value in case of error
                return 0;
            }
        }

        private int GetApprovalsCount()
        {
            try
            {
                var StaffNo = Session["Username"].ToString();
                var employee = Session["EmployeeData"] as EmployeeView;
                var UserID = employee?.UserID;

                //var page = "ApprovalEntries?$filter=Approver_ID eq '" + UserID + "' and Status eq 'Open'&$format=json";
                var page = "ApprovalEntries?$filter=Approver_ID eq '" + UserID + "' and Status eq 'Open'&$format=json";
                //var page = "ApprovalEntries";
                var httpResponse = Credentials.GetOdataData(page);

                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var responseContent = streamReader.ReadToEnd();
                    var approvalsData = JsonConvert.DeserializeObject<ApprovalsResponse>(responseContent);

                    return approvalsData?.value?.Count ?? 0;
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }

        private int GetImprestsCount()
        {
            try
            {
                var StaffNo = Session["Username"].ToString();
                var employee = Session["EmployeeData"] as EmployeeView;
                var UserID = employee?.UserID;
                var EMployeeNo = employee?.No;

                var page = "ApprovedImprestMemos?$filter=Requestor eq '" + EMployeeNo + "'&$format=json";
                //var page = "SafariImprest";
                var httpResponse = Credentials.GetOdataData(page);

                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var responseContent = streamReader.ReadToEnd();
                    var imprestsData = JsonConvert.DeserializeObject<ImprestResponse>(responseContent);

                    return imprestsData?.value?.Count ?? 0;
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }

        public JsonResult SubmitNOKApprovalRequest(string lineNo, string empNo)
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;
                var UserID = employee?.UserID;

                
                Credentials.ObjNav.FnSendNOKforApproval(Convert.ToInt32(lineNo), empNo);

                return Json(new { message = "Next of kin submitted for approval successfully!", success = true },
                    JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }
        public JsonResult CancelNOKApprovalRequest(string lineNo, string empNo)
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;
                var UserID = employee?.UserID;

                
                Credentials.ObjNav.FnCancelNOKforApproval(Convert.ToInt32(lineNo), empNo);

                return Json(new { message = "Next of kin approval request cancelled successfully!", success = true },
                    JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

        private int GetAssignedAssetsCount()
        {
            try
            {
                var StaffNo = Session["Username"].ToString();
                var page = $"FixedAssetCard?$filter=Responsible_Employee eq '{StaffNo}'&$format=json";
                //var page = $"FixedAssetCard";
                var httpResponse = Credentials.GetOdataData(page);

                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var responseContent = streamReader.ReadToEnd();
                    var assetsData = JsonConvert.DeserializeObject<AssetsResponse>(responseContent);

                    return assetsData?.value?.Count ?? 0;
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }

        private int GetTotalApprovals()
        {
            try
            {
                var StaffNo = Session["Username"].ToString();
                var employee = Session["EmployeeData"] as EmployeeView;
                var UserID = employee?.UserID;
                var page = "ApprovalEntries?$filter=Approver_ID eq '" + UserID + "'&$format=json";
                //var page = "ApprovalEntries";
                var httpResponse = Credentials.GetOdataData(page);
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var responseContent = streamReader.ReadToEnd();
                    var approvalsData = JsonConvert.DeserializeObject<ApprovalsResponse>(responseContent);
                    return approvalsData?.value?.Count ?? 0;
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }

        private int GetTotalImprests()
        {
            try
            {
                var StaffNo = Session["Username"].ToString();
                var employee = Session["EmployeeData"] as EmployeeView;
                var UserID = employee?.UserID;
                var EMployeeNo = employee?.No;
                var page = "ApprovedImprestMemos";
                //var page = "SafariImprest";
                var httpResponse = Credentials.GetOdataData(page);
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var responseContent = streamReader.ReadToEnd();
                    var imprestsData = JsonConvert.DeserializeObject<ImprestResponse>(responseContent);
                    return imprestsData?.value?.Count ?? 0;
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }

        private int GetTotalAssignedAssets()
        {
            try
            {
                var StaffNo = Session["Username"].ToString();
                var page = $"FixedAssetCard";
                //var page = $"FixedAssetCard";
                var httpResponse = Credentials.GetOdataData(page);
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var responseContent = streamReader.ReadToEnd();
                    var assetsData = JsonConvert.DeserializeObject<AssetsResponse>(responseContent);
                    return assetsData?.value?.Count ?? 0;
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }


        private int CalculateLeaveBalanceProgress(decimal leaveBalance)
        {
            var StaffNo = Session["Username"].ToString();
            // If leave balance is negative, return 100% (fully exhausted)
            if (leaveBalance <= 0)
            {
                return 100;
            }
            decimal reimbursedDays = 0;
            var leaveDays = CommonClass.GetLeaveBal(StaffNo, "ANNUAL");
            if (leaveDays[0] > 1)
                // availableDays = (s[0] + s[3]) - Math.Abs(s[2]);
                reimbursedDays = leaveDays[4];

            int totaleaveDays = Convert.ToInt32(reimbursedDays);

            return (int)((double)leaveBalance / totaleaveDays * 100);
        }

        private int CalculateImprestProgress(int Imprest, int TotalImprests)
        {
            // Assuming 30 is the maximum leave balance
            return (int)((double)Imprest / TotalImprests * 100);
        }

        private int CalculateAssignedAssetsProgress(int AssignedAssets, int TotalAssignedAssets)
        {
            // Assuming 30 is the maximum leave balance
            return (int)((double)AssignedAssets / TotalAssignedAssets * 100);
        }

        private int CalculateApprovalProgress(int Approvals, int TotalApprovals)
        {
            // Assuming 30 is the maximum leave balance
            return (int)((double)Approvals / TotalApprovals * 100);
        }



        public ActionResult PersonalProfile()
        {
            if (Session["Username"] == null)
                return RedirectToAction("Login", "Login");
            try
            {
                var StaffNo = Session["Username"].ToString();
                //var EmpView = Session["EmployeeData"] as EmployeeView;
                var rsrceReq = $"EmployeeList?$filter=No eq '{StaffNo}'&$format=json";
                var httpResponse = Credentials.GetOdataData(rsrceReq);
                using var streamReader = new StreamReader(httpResponse.GetResponseStream());
                var result = streamReader.ReadToEnd();
                var odataResponse = JsonConvert.DeserializeObject<ODataResponse<Employee>>(result);
                var employeeData = odataResponse?.Value?.FirstOrDefault();
                return View("PersonalProfile", employeeData);

                //return View(EmpView);
            }
            catch (Exception ex)
            {
                var erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return View("~/Views/Common/ErrorMessange.cshtml", erroMsg);
            }
        }

        public PartialViewResult NextOfKin()
        {
            try
            {
            var StaffNo = Session["Username"].ToString();
            var rsrceReq = $"HREmployeeNextOfKin?$filter=Employee_Code eq '{StaffNo}'&$format=json";
            //var rsrceReq = $"HREmployeeNextOfKin";
            var httpResponse = Credentials.GetOdataData(rsrceReq);
            using var streamReader = new StreamReader(httpResponse.GetResponseStream());
            var result = streamReader.ReadToEnd();
            var odataResponse = JsonConvert.DeserializeObject<ODataResponse<NextOfKin>>(result);
            var nextofkin = odataResponse?.Value ?? [];
                return PartialView("PartialView/NextOfKinList", nextofkin);

            }

            catch (Exception ex)
            {
                var erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return PartialView("~/Views/Common/ErrorMessange.cshtml", erroMsg);
            }
        }

        public PartialViewResult AddNextOfKin()
        {
            var nextOfKinView = new NextOfKin();

            var HrLookUpList = new List<DropdownList>();
            var pagehrLookup = "HrLookUp";
            var httpResponseHrlookup = Credentials.GetOdataData(pagehrLookup);
            using (var streamReader = new StreamReader(httpResponseHrlookup.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                var details = JObject.Parse(result);
                HrLookUpList.AddRange(from JObject config in details["value"] select new DropdownList { Text = $"{(string)config["Code"]} - {(string)config["Description"]}", Value = (string)config["Code"] });
            }

            nextOfKinView.ListOfRelationship = HrLookUpList.Select(x =>
                new SelectListItem
                {
                    Text = x.Text,
                    Value = x.Value
                }).ToList();

            return PartialView("PartialView/AddNextOfKinForm", nextOfKinView);
        }

        public JsonResult SubmitNextOfKin(NextOfKin nextOfKin)
        {
            try
            {
                var employee = Session["EmployeeData"] as EmployeeView;

                Credentials.ObjNav.InsertNextOfKin(nextOfKin.Employee_Code, nextOfKin.Relationship, nextOfKin.SurName, nextOfKin.Other_Names, nextOfKin.Date_Of_Birth, nextOfKin.Home_Tel_No, nextOfKin.E_mail, Convert.ToInt32(nextOfKin.Gender), nextOfKin.ID_No_Passport_No);

                return Json(new { message = "Next of kin added successfully", success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult DeleteNextOfKinLine(string employeeCode, string relationship, string lineNo, string id)
        {
            try
            {
                Credentials.ObjNav.DeleteNextOfKin(employeeCode, relationship, Convert.ToInt32(lineNo), id);

                return Json(new { message = "Next of kin deleted successfully", success = true },
                    JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = ex.Message.Replace("'", ""), success = false },
                    JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult PersonalProfile2()
        {
            if (Session["Username"] == null)
                return RedirectToAction("Login", "Login");
            try
            {
                var StaffNo = Session["Username"].ToString();
                var EmpView = Session["EmployeeData"] as EmployeeView;


                return View(EmpView);
            }
            catch (Exception ex)
            {
                var erroMsg = new Error();
                erroMsg.Message = ex.Message;
                return View("~/Views/Common/ErrorMessange.cshtml", erroMsg);
            }
        }


        public PartialViewResult ProfilePicture(string gender)
        {
            var EmpView = new EmployeeView();
            EmpView.Gender = gender;
            return PartialView("~/Views/Dashboard/ProfilePic.cshtml", EmpView);
        }

        public PartialViewResult EmployeeQualification()
        {
            try
            {
                var StaffNo = Session["Username"].ToString();
                return PartialView("~/Views/Dashboard/PartialView/EmployeeQualification.cshtml");
            }
            catch (Exception ex)
            {
                Error erroMsg = new Error
                {
                    Message = ex.Message
                };
                return PartialView("~/Views/Shared/Partial Views/ErroMessangeView.cshtml", erroMsg);
            }
        }
    }
}