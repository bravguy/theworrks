﻿using Latest_Staff_Portal.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace Latest_Staff_Portal.ViewModel
{
    public class PettyCash
    {
        public string No { get; set; }
        public DateTime Date { get; set; }
        public string Pay_Mode { get; set; }
        public string Paying_Bank_Account { get; set; }
        public string Bank_Name { get; set; }
        public string Account_Type { get; set; }
        public string Account_No { get; set; }
        public string Account_Name { get; set; }
        public string Funding_Source { get; set; }
        public string Workplan_Code { get; set; }
        public string Activity_Code { get; set; }
        public string Expenditure_Requisition_Code { get; set; }
        public string Payee { get; set; }
        public string Payment_Narration { get; set; }
        public string Shortcut_Dimension_1_Code { get; set; }
        public string Department_Name { get; set; }
        public string Shortcut_Dimension_2_Code { get; set; }
        public string Project_Name { get; set; }
        public string Shortcut_Dimension_3_Code { get; set; }
        public string Shortcut_Dimension_5_Code { get; set; }
        public string Unit_Name { get; set; }
        public string Currency_Code { get; set; }
        public decimal Total_Amount_LCY { get; set; }
        public string Status { get; set; }
        public string Payment_Type { get; set; }
        public string PV_Type { get; set; }
        public bool Posted { get; set; }
        public DateTime Posting_Date { get; set; }
    }

    public class PvLines
    {
        public string No { get; set; }
        public string Bounced_Pv_No { get; set; }
        public int Line_No { get; set; }
        public string Source_Document_No { get; set; }
        public string Account_No { get; set; }
        public string Type { get; set; }
        public string Account_Type { get; set; }
        public string Account_Name { get; set; }
        public string Shortcut_Dimension_3_Code { get; set; }
        public string Shortcut_Dimension_6_Code { get; set; }
        public decimal Amount { get; set; }
        public decimal Net_Amount { get; set; }
        public decimal Remaining_Amount { get; set; }
        public decimal VAT_Rate { get; set; }
        public decimal VAT_Six_Percent_Rate { get; set; }
        public string VAT_Withheld_Code { get; set; }
        public decimal VAT_Withheld_Amount { get; set; }
        public bool Budgetary_Control_A_C { get; set; }
        public decimal Advance_Recovery { get; set; }
        public decimal Retention_Amount { get; set; }
        public string Shortcut_Dimension_1_Code { get; set; }
        public string Shortcut_Dimension_2_Code { get; set; }
        public string Claim_Doc_No { get; set; }
        public string VAT_Code { get; set; }
        public string W_Tax_Code { get; set; }
        public string W_T_VAT_Code { get; set; }
        public decimal VAT_Amount { get; set; }
        public decimal W_Tax_Amount { get; set; }
        public decimal Total_Net_Pay { get; set; }
        public string Status { get; set; }
    }

    public class PvLinesViewModel
    {
        public string No { get; set; }
        public string AccountNo { get; set; }
        public string FundingSource { get; set; }
        public string VoteItem { get; set; }
        public Decimal Amount { get; set; }
        public List<SelectListItem> GlAccountList { get; set; } = new();
        public List<SelectListItem> ListOfFundingSource { get; set; } = new();
        public List<SelectListItem> ListOfVoteItem { get; set; } = new();
    }

    public class PettyCashViewModel
    {
        public string PaymentNarration { get; set; }
        public string UserId { get; set; }

    }

    public class PettyCashSurrender
    {
        public string No { get; set; }
        public string Job { get; set; }
        public string Job_Task_No { get; set; }
        public string Job_Name { get; set; }
        public string Project_Description { get; set; }
        public DateTime Date { get; set; }
        public string Pay_Mode { get; set; }
        public string Paying_Bank_Account { get; set; }
        public string Bank_Name { get; set; }
        public string Account_Type { get; set; }
        public string Account_No { get; set; }
        public string Account_Name { get; set; }
        public string Petty_Cash_No { get; set; }
        public string Payee { get; set; }
        public string Payment_Narration { get; set; }
        public string Shortcut_Dimension_1_Code { get; set; }
        public string Department_Name { get; set; }
        public string Shortcut_Dimension_2_Code { get; set; }
        public string Project_Name { get; set; }
        public string Shortcut_Dimension_3_Code { get; set; }
        public string Unit_Name { get; set; }
        public string Currency_Code { get; set; }
        public DateTime Posting_Date { get; set; }
        public decimal Total_Amount_LCY { get; set; }
        public decimal Actual_Petty_Cash_Amount_Spent { get; set; }
        public decimal Remaining_Petty_Cash_Amount { get; set; }
        public int Dimension_Set_ID { get; set; }
        public decimal Receipted_Petty_Cash_Amount { get; set; }
        public string Status { get; set; }
        public DateTime Surrender_Date { get; set; }
    }

    public class PvSurrenderLine
    {
        public string No { get; set; }
        public int Line_No { get; set; }
        public string Account_Type { get; set; }
        public string Account_No { get; set; }
        public string Account_Name { get; set; }
        public string Description { get; set; }
        public decimal Amount { get; set; }
        public decimal Actual_Spent { get; set; }
        public string Receipt_No { get; set; }
        public decimal Cash_Receipt_Amount { get; set; }
        public decimal Remaining_Amount { get; set; }
    }
    public class PvSurrenderViewModel
    {
        public string PettyCashNo { get; set; }
        public string PayMode { get; set; }
        public string UserId { get; set; }
        public List<SelectListItem> ListOfPayModes { get; set; } = new();
        public List<SelectListItem> ListOfApprovedPV { get; set; } = new();

    }




}