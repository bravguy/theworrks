﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace Latest_Staff_Portal.ViewModel
{
    public class ApprovedPurchaseRequisitions
    {

        public string Document_Type { get; set; }
        public string No { get; set; }
        public string PRN_Type { get; set; }
        public string Document_Date { get; set; }
        public string Location_Code { get; set; }
        public string Requisition_Product_Group { get; set; }
        public string Requester_ID { get; set; }
        public string Request_By_No { get; set; }
        public string Request_By_Name { get; set; }
        public string Shortcut_Dimension_1_Code { get; set; }
        public string Department_Name { get; set; }
        public string Shortcut_Dimension_2_Code { get; set; }
        public string Project_Name { get; set; }
        public string Procurement_Plan_ID { get; set; }
        public string Purchaser_Code { get; set; }
        public string Assigned_Officer { get; set; }
        public string Job { get; set; }
        public string Job_Task_No { get; set; }
        public string PP_Planning_Category { get; set; }
        public string Description { get; set; }
        public int PP_Total_Budget { get; set; }
        public int PP_Total_Actual_Costs { get; set; }
        public string PP_Solicitation_Type { get; set; }
        public string Other_Procurement_Methods { get; set; }
        public string PP_Bid_Selection_Method { get; set; }
        public string PP_Procurement_Method { get; set; }
        public string PP_Invitation_Notice_Type { get; set; }
        public string PP_Preference_Reservation_Code { get; set; }
        public string PRN_Conversion_Procedure { get; set; }
        public bool Ordered_PRN { get; set; }
        public string Linked_IFS_No { get; set; }
        public string Linked_LPO_No { get; set; }
        public bool Consolidate_PRN { get; set; }
        public string Consolidate_to_IFS_No { get; set; }
        public string Status { get; set; }
        public bool Notified { get; set; }

        public List<SelectListItem> ListOfLocation_Code { get; set; }
        public List<SelectListItem> ListOfProgramme { get; set; }
        public List<SelectListItem> ListOfDepartment { get; set; }
        public List<SelectListItem> ListOfProcurementPlans { get; set; }
        public List<SelectListItem> ListOfAssigned_Officer { get; set; }
        public List<SelectListItem> ListOfPP_Planning_Category { get; set; }
        public List<SelectListItem> ListOfPP_Preference_Reservation_Code { get; set; }
        public List<SelectListItem> ListOfPP_Solicitation_Type { get; set; }
    }


    public class PurchaseRequisitionLines
    {
        public string DocumentType { get; set; }
        public string DocumentNo { get; set; }
        public int LineNo { get; set; }
        public bool LineSelected { get; set; }
        public string Type { get; set; }
        public string ProcurementPlanID { get; set; }
        public string Budget { get; set; }
        public string BudgetLine { get; set; }
        public string Status { get; set; }
        public int ProcurementPlanEntryNo { get; set; }
        public string ItemDescription { get; set; }
        public string PPSolicitationType { get; set; }
        public string PPProcurementMethod { get; set; }
        public string OtherProcurementMethods { get; set; }
        public string PPPreferenceReservationCode { get; set; }
        public string ItemCategoryCode { get; set; }
        public string No { get; set; }
        public string Description { get; set; }
        public string UnitOfMeasureCode { get; set; }
        public int Quantity { get; set; }
        public int DirectUnitCost { get; set; }
        public int Amount { get; set; }
        public int AmountIncludingVAT { get; set; }
        public string CurrencyCode { get; set; }
        public string LocationCode { get; set; }
        public int UnitCostLCY { get; set; }
        public string ContractNoToPay { get; set; }
        public bool LPOCreated { get; set; }
        public List<SelectListItem> ListOfProcurementPlans { get; set; }
        public List<SelectListItem> ListOfBudget { get; set; }
        public List<SelectListItem> ListOfBudget_Line { get; set; }
        public List<SelectListItem> ListOfProcurement_Plan_Entry { get; set; }
        public List<SelectListItem> ListOfPP_Preference_Reservation_Code { get; set; }
        public List<SelectListItem> ListOfPP_Planning_Category { get; set; }
        public List<SelectListItem> ListOfItems { get; set; }
        public List<SelectListItem> ListOfItemsUOM { get; set; }
        public List<SelectListItem> ListOfLocations { get; set; }
    }

    public class PrnLineViewModel
    {
        public string No { get; set; }
        public int PlanningCategory { get; set; }
        public string TechnicalSpecification { get; set; }
        public string Item { get; set; }
        public decimal DirectUnitCost { get; set; }
        public int Quantity { get; set; }
        public string Requisition_Product_Group { get; set; }
        public string FaNo { get; set; }
        public List<SelectListItem> ListOfItemFaNo { get; set; }
    }
    public class PurchaseRequisitionLinesList
    {
        public string Status { get; set; }
        public string Procurement_Plan_ID { get; set; }

        public int Procurement_Plan_Category { get; set; }
        public List<PurchaseRequisitionLines> ListOfPurchaseRequisitionLines { get; set; }
    }
    public class ExpensePRNLine
    {
        public string DocumentNo { get; set; }
        public int LineNo { get; set; }
        public int ProcPlanEntryNo { get; set; }
        public string procurementPlanID { get; set; }
        public string Item { get; set; }
        public string EntryNo { get; set; }
        public List<SelectListItem> ListOfProcurementPlanNos { get; set; }
        public List<SelectListItem> ListOfProcurementItems { get; set; }
        public string ProcType { get; set; }
        public int pType { get; set; }
        public string No { get; set; }
        public string Name { get; set; }
        public string UnitOfMeasure { get; set; }
        public int Quantity { get; set; }
        public decimal Rate { get; set; }
        public decimal Total { get; set; }
        public string ExpenseDescription { get; set; }
        public string GLAccount { get; set; }
        public string Status { get; set; }
        public string RecalledBy { get; set; }
        //public string procurementPlanID { get; set; }
        public DateTime RecalledOn { get; set; }
        public string SourceLineNo { get; set; }
        public decimal AvailableBudget { get; set; }
    }

    public class ExpenseLine
    {
        public string Document_No { get; set; }
        public int Line_No { get; set; }
        public int ProcPlan_Entry_No { get; set; }
        public string Proc_Type { get; set; }
        public string No { get; set; }
        public string Name { get; set; }
        public string Unit_of_Measure { get; set; }
        public decimal Quantity { get; set; }
        public decimal Rate { get; set; }
        public decimal Total { get; set; }
        public decimal Available_Amount { get; set; }
        public string Expense_Description { get; set; }
        public string G_L_Account { get; set; }
        public string Status { get; set; }
        public string Recalled_By { get; set; }
        public DateTime Recalled_On { get; set; }
        public int Source_Line_No { get; set; }
    }
    //public class ExpenseLine
    //{
    //    public string Document_No { get; set; }
    //    public int Line_No { get; set; }
    //    public int ProcPlan_Entry_No { get; set; }
    //    public string Proc_Type { get; set; }
    //    public string No { get; set; }
    //    public string Name { get; set; }
    //    public string Unit_of_Measure { get; set; }
    //    public decimal Quantity { get; set; }
    //    public decimal Rate { get; set; }
    //    public decimal Total { get; set; }
    //    public decimal Available_Amount { get; set; }
    //    public string Expense_Description { get; set; }
    //    public string G_L_Account { get; set; }
    //    public string Status { get; set; }
    //    public string Recalled_By { get; set; }
    //    public DateTime Recalled_On { get; set; }
    //    public int Source_Line_No { get; set; }
    //}


    public class ExpensePRNLineList
    {
        public string Status { get; set; }
        public List<ExpensePRNLine> ListOfExpensePRNLine { get; set; }
    }

    public class PurchaseRequisitionLine
    {
        public string Document_Type { get; set; }
        public string Document_No { get; set; }
        public int Line_No { get; set; }
        public string ProcurementPlanID { get; set; }
        public string Type { get; set; }
        public string Control6 { get; set; }
        public string Item_FA_No { get; set; }
        public string No { get; set; }
        public string Description { get; set; }
        public string TechnicalSpecifications { get; set; }
        public string UnitofMeasureCode { get; set; }
        public decimal QuantityInStore { get; set; }
        public decimal Quantity { get; set; }
        public decimal Direct_Unit_Cost_Inc_VAT { get; set; }
        public decimal Amount { get; set; }
        public decimal AmountIncludingVAT { get; set; }
        public string CurrencyCode { get; set; }
        public string LocationCode { get; set; }
        public decimal UnitCostLCY { get; set; }
        public string VATProdPostingGroup { get; set; }
        public string ItemCategoryCode { get; set; }
        public string Shortcut_Dimension_1_Code { get; set; }
        public string Budget { get; set; }
        public string Budget_Line { get; set; }
        public decimal PPTotalAvailableBudget { get; set; }
        public string Shortcut_Dimension_2_Code { get; set; }
        public string PPFundingSourceID { get; set; }
        public decimal PPTotalBudget { get; set; }
        public decimal PPTotalActualCosts { get; set; }
        public decimal PPTotalCommitments { get; set; }
        public string PPSolicitationType { get; set; }
        public string PPProcurementMethod { get; set; }
        public string PPPreferenceReservationCode { get; set; }
        public string PRNConversionProcedure { get; set; }
    }
    public class PurchaseRequisition
    {
        public string Document_Type { get; set; }
        public string No { get; set; }
        public string PRN_Type { get; set; }
        public DateTime Document_Date { get; set; }
        public string Location_Code { get; set; }
        public string Requisition_Product_Group { get; set; }
        public string Solicitation_Type { get; set; }
        public string Priority_Level { get; set; }
        public string Requester_ID { get; set; }
        public string Request_By_No { get; set; }
        public string Request_By_Name { get; set; }
        public string Shortcut_Dimension_1_Code { get; set; }
        public string Geographical_Location_Name { get; set; }
        public string Shortcut_Dimension_2_Code { get; set; }
        public string Admin_Unit_Name { get; set; }
        public string Procurement_Plan_ID { get; set; }
        public string PP_Planning_Category { get; set; }
        public string Description { get; set; }
        public decimal Plan_Amount { get; set; }
        public decimal Committed_Plan_Amount { get; set; }
        public decimal Available_Plan_Amount { get; set; }
        public string Job { get; set; }
        public string Job_Task_No { get; set; }
        public decimal PP_Total_Budget { get; set; }
        public decimal Requisition_Amount { get; set; }
        public string PP_Solicitation_Type { get; set; }
        public string PP_Procurement_Method { get; set; }
        public string PP_Preference_Reservation_Code { get; set; }
        public string PP_Invitation_Notice_Type { get; set; }
        public string PRN_Conversion_Procedure { get; set; }
        public string Consolidate_to_IFS_No { get; set; }
        public string Status { get; set; }
        public List<SelectListItem> ListOfLocation_Code { get; set; }
        public List<SelectListItem> ListOfProgramme { get; set; }
        public List<SelectListItem> ListOfDepartment { get; set; }
        public List<SelectListItem> ListOfProcurementPlans { get; set; }
        public List<SelectListItem> ListOfAssigned_Officer { get; set; }
        public List<SelectListItem> ListOfPP_Planning_Category { get; set; }
        public List<SelectListItem> ListOfPP_Preference_Reservation_Code { get; set; }
        public List<SelectListItem> ListOfPP_Solicitation_Type { get; set; }
    }
    public class AppprovedPrnLines
    {
        public string Document_Type { get; set; }
        public string Document_No { get; set; }
        public int Line_No { get; set; }
        public bool Line_Selected { get; set; }
        public string Type { get; set; }
        public string Procurement_Plan_ID { get; set; }
        public string Item_FA_No { get; set; }
        public string No { get; set; }
        public string Description { get; set; }
        public string TechnicalSpecifications { get; set; }
        public string UnitofMeasureCode { get; set; }
        public decimal Quantity { get; set; }
        public string Budget { get; set; }
        public string Budget_Line { get; set; }
        public string Status { get; set; }
        public int Procurement_Plan_Entry_No { get; set; }
        public string Item_Description { get; set; }
        public string PP_Solicitation_Type { get; set; }
        public string PP_Procurement_Method { get; set; }
        public string Other_Procurement_Methods { get; set; }
        public string PP_Preference_Reservation_Code { get; set; }
        public string Item_Category_Code { get; set; }
        public string Control6 { get; set; }
        public decimal Direct_Unit_Cost { get; set; }
        public decimal Amount { get; set; }
        public decimal Amount_Including_VAT { get; set; }
        public string Currency_Code { get; set; }
        public string Location_Code { get; set; }
        public decimal Awarded_Quantity { get; set; }
        public decimal Awarded_Unit_Cost { get; set; }
        public decimal Awarded_Line_Amount { get; set; }
        public decimal Unit_Cost_LCY { get; set; }
        public string Contract_No_to_pay { get; set; }
        public bool LPO_Created { get; set; }
    }



}