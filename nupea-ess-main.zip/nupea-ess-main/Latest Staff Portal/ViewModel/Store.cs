﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace Latest_Staff_Portal.ViewModel
{

    public class StoreRequisitions
    {

        public string Document_Type { get; set; }
        public string No { get; set; }
        public string Requester_ID { get; set; }
        public string Request_By_No { get; set; }
        public string Request_By_Name { get; set; }
        public bool HOD { get; set; }
        public string Location_Code { get; set; }
        public string Order_Date { get; set; }
        public string Description { get; set; }
        public string Requisition_Type { get; set; }
        public string Status { get; set; }
        public string Shortcut_Dimension_1_Code { get; set; }
        public string Department_Name { get; set; }
        public string Shortcut_Dimension_2_Code { get; set; }
        public string Project_Name { get; set; }
        public int No_of_Archived_Versions { get; set; }
        public string Budget_Item { get; set; }

        public List<SelectListItem> ListOfLocation_Code { get; set; }
        public List<SelectListItem> ListOfProgramme { get; set; }
        public List<SelectListItem> ListOfDepartment { get; set; }

    }


    public class StoreRequisitionsLines
    {
        public string Document_Type { get; set; }
        public string Document_No { get; set; }
        public int Line_No { get; set; }
        public string Item_Category { get; set; }
        public string Service_Item_Code { get; set; }
        public string Type { get; set; }
        public string No { get; set; }
        public string Description { get; set; }
        public string Location_Code { get; set; }
        public string Variant_Code { get; set; }
        public string Unit_of_Measure_Code { get; set; }
        public int Quantity_In_Store { get; set; }
        public int Qty_Requested { get; set; }
        public List<SelectListItem> ListOfPP_Planning_Category { get; set; }
        public List<SelectListItem> ListOfItems { get; set; }
        public List<SelectListItem> ListOfDescription { get; set; }
        public List<SelectListItem> ListOfLocations { get; set; }
    }
    public class ApprovedStoreRequisition
    {
        public string Document_Type { get; set; }
        public string No { get; set; }
        public string Requester_ID { get; set; }
        public string Request_By_No { get; set; }
        public string Request_By_Name { get; set; }
        public string Location_Code { get; set; }
        public DateTime Order_Date { get; set; }
        public string Description { get; set; }
        public string Requisition_Type { get; set; }
        public string Currency_Code { get; set; }
        public string Status { get; set; }
        public string Shortcut_Dimension_1_Code { get; set; }
        public string Department_Name { get; set; }
        public string Shortcut_Dimension_2_Code { get; set; }
        public string Project_Name { get; set; }
        public string Shortcut_Dimension_3_Code { get; set; }
        public string Unit_Name { get; set; }
        public decimal Requisition_Amount { get; set; }
        public int No_of_Archived_Versions { get; set; }
    }
    public class ApprovedStoreRequisitionLine
    {
        public string Document_Type { get; set; }
        public string Document_No { get; set; }
        public int Line_No { get; set; }
        public bool Select { get; set; }
        public string Category { get; set; }
        public string Item_Category_Code { get; set; }
        public string Service_Item_Code { get; set; }
        public string Type { get; set; }
        public string No { get; set; }
        public string Description { get; set; }
        public string Variant_Code { get; set; }
        public string Employee_No { get; set; }
        public string Employee_Name { get; set; }
        public string Unit_of_Measure_Code { get; set; }
        public decimal Qty_Requested { get; set; }
        public decimal Quantity_issued { get; set; }
        public decimal Quantity_To_Issue { get; set; }
        public string Remarks { get; set; }
        public decimal Quantity_In_Store { get; set; }
        public decimal Qty_on_Purch_Order { get; set; }
        public string Location_Code { get; set; }
    }

    public class StoreRequisitionViewModel
    {
        public string Description { get; set; }
        public string LocationCode { get; set; }
        public string No { get; set; }
        public List<SelectListItem> ListOfLocationCodes { get; set; }
    }

    public class StoreRequisitionModel
    {

        [JsonProperty("Document_Type")]
        public string Document_Type { get; set; }

        [JsonProperty("No")]
        public string No { get; set; }

        [JsonProperty("Requester_ID")]
        public string Requester_ID { get; set; }

        [JsonProperty("Request_By_No")]
        public string Request_By_No { get; set; }

        [JsonProperty("Request_By_Name")]
        public string Request_By_Name { get; set; }

        [JsonProperty("HOD")]
        public bool HOD { get; set; }

        [JsonProperty("Location_Code")]
        public string Location_Code { get; set; }

        [JsonProperty("Order_Date")]
        public DateTime Order_Date { get; set; }

        [JsonProperty("Description")]
        public string Description { get; set; }

        [JsonProperty("Requisition_Type")]
        public string Requisition_Type { get; set; }

        [JsonProperty("Status")]
        public string Status { get; set; }

        [JsonProperty("Shortcut_Dimension_1_Code")]
        public string Shortcut_Dimension_1_Code { get; set; }

        [JsonProperty("Department_Name")]
        public string Department_Name { get; set; }

        [JsonProperty("Shortcut_Dimension_2_Code")]
        public string Shortcut_Dimension_2_Code { get; set; }

        [JsonProperty("Project_Name")]
        public string Project_Name { get; set; }

        [JsonProperty("No_of_Archived_Versions")]
        public bool No_of_Archived_Versions { get; set; }

        [JsonProperty("Budget_Item")]
        public string Budget_Item { get; set; }

    }
    public class MUOModel
    {

        public string Code { get; set; }
        public DateTime Start_Date { get; set; }
        public string Duration_Formula { get; set; }
        public DateTime Expiry_Notice_Date { get; set; }
        public DateTime Execution_Date { get; set; }
        public string Parties_Involved { get; set; }
        public string Purpose_of_MOU { get; set; }
        public string Cooperation_Areas { get; set; }
        public string Contact_Persons_Email { get; set; }
        public string MOU_Status { get; set; }
        public string Status { get; set; }
        public string Approval_Entity { get; set; }
        public string Remarks { get; set; }
    }

}