﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace Latest_Staff_Portal.ViewModel
{
    public class ImprestMemoList
    {
        public string No { get; set; }
        public string Warrant_Voucher_Type { get; set; }
        public string Warrant_No { get; set; }
        public string Date { get; set; }
        public string Subject { get; set; }
        public string Objective { get; set; }
        public string Terms_of_Reference { get; set; }
        public string Imprest_Naration { get; set; }
        public string User_ID { get; set; }
        public string Requestor { get; set; }
        public string Requestor_Name { get; set; }
        public bool HOD { get; set; }
        public string Start_Date { get; set; }
        public int No_of_days { get; set; }
        public string End_Date { get; set; }
        public string Return_Date { get; set; }
        public string Due_Date { get; set; }
        public int Total_Subsistence_Allowance { get; set; }
        public int Total_Fuel_Costs { get; set; }
        public int Total_Maintenance_Costs { get; set; }
        public int Total_Casuals_Cost { get; set; }
        public int Total_Other_Costs { get; set; }
        public string Status { get; set; }
        public string Global_Dimension_1_Code { get; set; }
        public string Department_Name { get; set; }
        public string Global_Dimension_2_Code { get; set; }
        public string Project_Name { get; set; }
        public int Dimension_Set_ID { get; set; }
        public string Strategic_Plan { get; set; }
        public string Reporting_Year_Code { get; set; }
        public string Workplan_Code { get; set; }
        public string Activity_Code { get; set; }
        public string Expenditure_Requisition_Code { get; set; }
        public string Reason_to_Reopen { get; set; }
        public string From { get; set; }
        public string Destination { get; set; }
        public string Time_Out { get; set; }
        public string Journey_Route { get; set; }
        public string Work_Type_Filter { get; set; }
        public List<SelectListItem> ListOfDim1 { get; set; }
        public List<SelectListItem> ListOfDim2 { get; set; }
        public List<SelectListItem> ListOfDim3 { get; set; }
        public List<SelectListItem> ListOfStratPlans { get; set; }
        public List<SelectListItem> ListOfWorkplanActivities { get; set; }
        public List<SelectListItem> ListOfImplementationYears { get; set; }
        public List<SelectListItem> ListOfExpenseRequisitions { get; set; }

        public List<SelectListItem> ListOfDim4 { get; set; }
        public List<SelectListItem> ListOfDim5 { get; set; }

        public List<SelectListItem> ListOfResponsibility { get; set; }
        public List<SelectListItem> ListOfImprestDue { get; set; }
        public List<SelectListItem> ListOfEmployeeList { get; set; }
        public List<SelectListItem> ListOfEmployeeLists { get; set; }
    }

    public class NewImprestMemoRequisition
    {
        public string Dim1 { get; set; }
        public string Dim2 { get; set; }
        public string Dim3 { get; set; }
        public string Dim4 { get; set; }
        public string Dim5 { get; set; }
        public string RespC { get; set; }
        public string UoM { get; set; }
        public string ImprestDueType { get; set; }
        public List<SelectListItem> ListOfDim1 { get; set; }
        public List<SelectListItem> ListOfDim2 { get; set; }
        public List<SelectListItem> ListOfDim3 { get; set; }
        public List<SelectListItem> ListOfDim4 { get; set; }
        public List<SelectListItem> ListOfDim5 { get; set; }
        public List<SelectListItem> ListOfResponsibility { get; set; }
        public List<SelectListItem> ListOfImprestDue { get; set; }
        public List<SelectListItem> ListOfEmployeeList { get; set; }
        public List<SelectListItem> ListOfEmployeeLists { get; set; }
        public string To { get; set; }
        public string From { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }

    }

    public class ImprestMemoTypes
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }

    public class EmployeeList
    {
        public string No { get; set; }
        public string Name { get; set; }
    }

    public class ImprestMemoTypes2
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }

    public class ImprestMemoTypesList
    {
        public string Code { get; set; }
        public string Code2 { get; set; }
        public List<SelectListItem> ListOfImprestTypes { get; set; }
        public List<SelectListItem> ListOfUnitMeasure { get; set; }
        public List<SelectListItem> ListOfDestination { get; set; }
        public List<SelectListItem> ListOfEmployeeList { get; set; }
        public List<SelectListItem> ListOfImprestTypes2 { get; set; }
    }

    public class ImprestMemoHeader
    {
        public string No { get; set; }
        public string DateNeeded { get; set; }
        public string DocumentDate { get; set; }
        public string Remarks { get; set; }
        public NewImprestMemoRequisition DocD { get; set; }
        public string Status { get; set; }
        public string TotalAmount { get; set; }
        public string RequestorNo { get; set; }
        public string RequestorName { get; set; }
        public string Dim1 { get; set; }
        public string Dim2 { get; set; }
        public string Dim3 { get; set; }
        public string Dim4 { get; set; }
        public string Dim5 { get; set; }
        public string ImprestDueType { get; set; }
        public string To { get; set; }
        public string From { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public List<SelectListItem> ListOfEmployeeList { get; set; }
        public List<SelectListItem> ListOfImprestDue { get; set; }
    }

    public class ImprestMemoLines
    {
        public string DocNo { get; set; }
        public string EmployeeNo { get; set; }
        public string AdvanceType { get; set; }
        public string Item { get; set; }
        public string ItemDesc { get; set; }
        public string ItemDesc2 { get; set; }
        public string Quantity { get; set; }
        public string UnitAmount { get; set; }
        public string Amount { get; set; }
        public string UoN { get; set; }
        public string Desination { get; set; }
        public string LnNo { get; set; }
    }

    public class ImprestMemoLinesList
    {
        public string Status { get; set; }
        public List<ImprestMemoLines> ListOfImprestMemoLines { get; set; }
    }

    public class ImprestMemoItemDetails
    {
        public string Code { get; set; }
        public List<SelectListItem> ListOfImprestTypes { get; set; }
        public List<SelectListItem> ListOfImprestTypes2 { get; set; }
        public List<SelectListItem> ListOfUoM { get; set; }
        public List<SelectListItem> ListOfDestination { get; set; }
        public ImprestMemoLines ItemDetails { get; set; }
    }

    public class ImprestMemoItemsList
    {
        public string Status { get; set; }
        public List<ImprestMemoLines> ListOfImprestMemoLines { get; set; }
    }

    public class ImprestMemoDocument
    {
        public ImprestMemoHeader DocHeader { get; set; }
        public NewImprestMemoRequisition DocD { get; set; }
        public List<ImprestMemoLines> ListOfImprestMemoLines { get; set; }
        public List<ImprestMemoNonStaff> ListOfImprestMemoNonStaff { get; set; }
        public List<ImprestMemoItems> ListOfImprestMemoItemsList { get; set; }
    }

    public class ImprestMemoNonStaff
    {
        public string Names { get; set; }
        public string ImprestMemoNo { get; set; }
        public string LineNo { get; set; }
        public string Organization { get; set; }
        public string Designation { get; set; }
    }

    public class ImprestMemoNonStaffList
    {
        public ImprestMemoNonStaff NonStaff { get; set; }
        public List<ImprestMemoNonStaff> ListOfNonstaff { get; set; }
        public string Code { get; set; }
        public string Status { get; set; }
    }

    public class ImprestMemoItems
    {
        public string DocNo { get; set; }
        public string EmployeeNo { get; set; }
        public string AdvanceType { get; set; }
        public string Item { get; set; }
        public string ItemDesc { get; set; }
        public string ItemDesc2 { get; set; }
        public string Quantity { get; set; }
        public string UnitAmount { get; set; }
        public string Amount { get; set; }
        public string UoN { get; set; }
        public string Desination { get; set; }
        public string LnNo { get; set; }
    }
    public class SafariTeam2
    {
        public string Imprest_Memo_No { get; set; }
        public int Line_No { get; set; }
        public string Work_Type { get; set; }
        public string Type { get; set; }
        public string Type_of_Expense { get; set; }
        public string No { get; set; }
        public string G_L_Account { get; set; }
        public string Task_No { get; set; }
        public string Name { get; set; }
        public string Unit_of_Measure { get; set; }
        public string Currency_Code { get; set; }
        public int Time_Period { get; set; }
        public int Direct_Unit_Cost { get; set; }
        public int Entitlement { get; set; }
        public int Transport_Costs { get; set; }
        public int Total_Entitlement { get; set; }
        public int Outstanding_Amount { get; set; }
        public string Tasks_to_Carry_Out { get; set; }
        public string Expected_Output { get; set; }
        public int Delivery { get; set; }
        public bool Project_Lead { get; set; }
        public string Dimension1Code { get; set; }
        public string Dimension2Code { get; set; }
        public string Dimension3Code { get; set; }
        public string Dimension4Code { get; set; }
        public string Dimension5Code { get; set; }
        public string Dimension6Code { get; set; }
        public string Dimension7Code { get; set; }
        public string Dimension8Code { get; set; }
        public List<SelectListItem> ListOfImprestTypes { get; set; }
        public List<SelectListItem> ListOfResources { get; set; }
        public List<SelectListItem> ListOfUOM { get; set; }
        public List<SelectListItem> ListOfCurrencies { get; set; }


    }
    public class ImprestMemoLine
    {
        public string Imprest_Memo_No { get; set; }
        public int Line_No { get; set; }
        public string Work_Type { get; set; }
        public string Type { get; set; }
        public string Type_of_Expense { get; set; }
        public string G_L_Account { get; set; }
        public string No { get; set; }
        public string G_L_Account_Total_Daily_Subsistence_Allowance { get; set; }
        public string G_L_Account_Total_Mileage_Cost { get; set; }
        public string G_L_Account_Transport_Costs { get; set; }
        public string Task_No { get; set; }
        public string Name { get; set; }
        public string Shortcut_Dimension_3_Code { get; set; }
        public string Shortcut_Dimension_6_Code { get; set; }
        public string Unit_of_Measure { get; set; }
        public string Currency_Code { get; set; }
        public int Time_Period { get; set; }
        public decimal Direct_Unit_Cost { get; set; }
        public decimal Entitlement { get; set; }
        public decimal Total_Entitlement { get; set; }
        public decimal Outstanding_Amount { get; set; }
        public string Tasks_to_Carry_Out { get; set; }
        public string Expected_Output { get; set; }
        public decimal Delivery { get; set; }
        public bool Project_Lead { get; set; }
        public string Dimension1Code { get; set; }
        public string Dimension2Code { get; set; }
        public string Dimension3Code { get; set; }
        public string Dimension4Code { get; set; }
        public string Dimension5Code { get; set; }
        public string Dimension6Code { get; set; }
        public string Dimension7Code { get; set; }
        public string Dimension8Code { get; set; }
        public decimal Mileage_KM { get; set; }
    }

    public class ImprestMemoViewModel
    {
        public string Subject { get; set; }
        public string Objective { get; set; }
        public string ImprestNaration { get; set; }
        public string UserID { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime TripExpectedEndDate { get; set; }
        public int NoOfDays { get; set; }
    }

    public class SafariTeamViewModel
    {
        public string No { get; set; }
        //public string AccountNo { get; set; }
        public string Destination { get; set; }
        public string FundingSource { get; set; }
        public string VoteItem { get; set; }
        public string ClaimTypes { get; set; }
        public string EmployeeNo { get; set; }
        public Decimal Amount { get; set; }
        public int NoOfDays { get; set; }
        public bool ProjectLead { get; set; }
        public List<SelectListItem> ListOfClaimTypes { get; set; } = new();
        public List<SelectListItem> ListOfFundingSource { get; set; } = new();
        public List<SelectListItem> ListOfVoteItem { get; set; } = new();
        public List<SelectListItem> ListOfDestinations { get; set; } = new();
        public List<SelectListItem> ListOfEmployees { get; set; } = new();
    }
    
    public class OtherCostViewModel
    {
        public string No { get; set; }
        public string FundingSource { get; set; }
        public string VoteCode { get; set; }
        public string ClaimTypes { get; set; }
        public string RequiredFor { get; set; }
        public decimal UnitCost { get; set; }
        public int NoOfDays { get; set; }
        public List<SelectListItem> ListOfClaimTypes { get; set; } = new();
        public List<SelectListItem> ListOfFundingSource { get; set; } = new();
        public List<SelectListItem> ListOfVoteCode { get; set; } = new();
    }
    public class OtherCostLine
    {
        public string Imprest_Memo_No { get; set; }
        public int Line_No { get; set; }
        public string Document_No { get; set; }
        public string Type { get; set; }
        public string Type_of_Expense { get; set; }
        public string Description { get; set; }
        public string No { get; set; }
        public string Required_For { get; set; }
        public string Shortcut_Dimension_3_Code { get; set; }
        public string Shortcut_Dimension_6_Code { get; set; }
        public int No_of_Days { get; set; }
        public decimal Unit_Cost { get; set; }
        public decimal Line_Amount { get; set; }
    }


}