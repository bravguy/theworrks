using System;
using System.Configuration;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Latest_Staff_Portal.Models;
using Newtonsoft.Json;

public static class RetrieveDocuments
{
    static RetrieveDocuments()
    {
        ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;
    }

    //public static async Task<dynamic> RetrieveDocument(string module, string documentNo, string documentType, string documentId)
    public static async Task<dynamic> RetrieveDocument(EdmsRetrieveDocument edmsRetrieveDocument)
    {


        var requestBody = new EdmsRetrieveDocument
        {
            //Client = edmsRetrieveDocument.Client,
            Client = "NUPEA",
            DocumentId = edmsRetrieveDocument.DocumentId,
            Module = edmsRetrieveDocument.Module,
        };

        var url = ConfigurationManager.AppSettings["EDMSURI"] + "EDMSRetrieve";
        if (string.IsNullOrEmpty(url))
        {
            return "";
        }

        var jsonPayload = JsonConvert.SerializeObject(requestBody);
        var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

        try
        {
            using (var httpClient = new HttpClient())
            {
                var response = await httpClient.PostAsync(url, content);

                if (response.IsSuccessStatusCode)
                {
                    var responseBody = await response.Content.ReadAsStringAsync();
                    var fileResponse = JsonConvert.DeserializeObject<FileResponse>(responseBody);

                    if (fileResponse != null && fileResponse.status_code == 0)
                    {
                        return new { Base64 = fileResponse.FileBase64String, MimeType = fileResponse.Mime };
                    }
                    return null;
                }
                return "";
            }
        }
        catch (HttpRequestException e)
        {
            return "";
        }
        catch (Exception ex)
        {
            return "";
        }
    }
}
